#!/bin/sh
# ============================================================
#  DECES v3.2 — instalador para macOS / Linux
#  Requisito único: Python 3.10+ (en Mac: `brew install python` o python.org)
# ============================================================
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "[DECES] Verificando Python..."
if command -v python3 >/dev/null 2>&1; then PY=python3; else PY=python; fi
$PY --version || { echo "[ERROR] Instala Python 3.10+ primero."; exit 1; }

echo "[DECES] Instalando dependencias (sympy, z3-solver)..."
$PY -m pip install --user --upgrade pip >/dev/null
$PY -m pip install --user sympy z3-solver

echo "[DECES] Corriendo la suite de verificación (7 casos históricos)..."
$PY "$DIR/deces.py" test --no-llm

cat <<'EOF'
============================================================
 LISTO. Para auditar un claim:
   python3 deces.py audit "tu afirmación científica" --claro
 Para auditar un archivo:
   python3 deces.py audit --input mi_paper.txt --claro
 Manual en lenguaje simple: MANUAL_HUMANO.md
============================================================
EOF
