#!/usr/bin/env python3
"""
test_deces.py — Test histórico para DECES v3.0
Valida que DECES produce veredictos correctos en casos conocidos.

v3.0: añade tests de memoria (cache hit / similar / clear).

Casos:
  - OPERA superluminal neutrinos → esperado nivel 0 (CONTRADICHA)
  - Éter luminífero → esperado nivel 0
  - Bekenstein-Hawking entropy → esperado nivel 5
  - Vulcano (planeta intramercurial) → esperado nivel 0
  - Cold fusion (Fleischmann-Pons) → esperado nivel 0
  - Hipótesis de la relatividad general (claims básicos) → esperado nivel 4-5
  - Mochizuki ABC proof (sin aceptar) → esperado nivel 2

Criterio de parada: si precisión < 70% en casos claros, abortar.
"""

import sys
import os
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from deces import audit, EpistemicLevel, get_db, DB_PATH


HISTORICAL_CASES = [
    {
        "nombre": "OPERA superluminal neutrinos",
        "claim": (
            "Los neutrinos del experimento OPERA viajan más rápido que la velocidad de la luz c. "
            "La medición muestra un adelanto de 60 nanosegundos respecto al tiempo esperado. "
            "Esto viola la relatividad especial de Einstein. Los neutrinos tendrían masa imaginaria "
            "y podrían viajar backward in time. Predicción: los neutrinos de alta energía llegarán "
            "antes que los fotones desde fuentes cósmicas distantes."
        ),
        "esperado": 0,
    },
    {
        "nombre": "Éter luminífero",
        "claim": (
            "El éter luminífero es el medio material a través del cual se propaga la luz. "
            "Es estacionario y absoluto. La Tierra se mueve a través del éter a 30 km/s. "
            "Predicción: la velocidad de la luz medida en la Tierra depende de la dirección "
            "del movimiento terrestre. El experimento de Michelson-Morley debería detectar "
            "una diferencia de velocidad de 30 km/s entre direcciones perpendiculares."
        ),
        "esperado": 0,
    },
    {
        "nombre": "Bekenstein-Hawking entropy",
        "claim": (
            "La entropía de un agujero negro es proporcional al área de su horizonte de sucesos: "
            "S = A / (4 * G * hbar). El área A = 4 * pi * r_s^2 donde r_s = 2GM/c^2. "
            "Predicción: S = 4*pi*G*M^2 / (hbar * c^3). La temperatura de Hawking es "
            "T_H = hbar * c^3 / (8 * pi * G * M * k_B). El área del horizonte nunca decrece: dA/dt >= 0. "
            "Esto es consistente con LIGO O1 (11 eventos BBH), LIGO O3 (56 eventos), "
            "M-sigma relation (52 galaxies), y mediciones de S2 orbit en Sgr A*."
        ),
        "esperado": 5,
    },
    {
        "nombre": "Vulcano (planeta intramercurial)",
        "claim": (
            "Vulcano es un planeta que orbita entre Mercurio y el Sol. Su existencia explica "
            "la precesión anómala del perihelio de Mercurio. Predicción: Vulcano debería ser "
            "observable durante eclipses solares totales como un punto brillante cerca del Sol. "
            "Su masa debería ser suficiente para causar la precesión observada de 43 arcosegundos "
            "por siglo."
        ),
        "esperado": 0,
    },
    {
        "nombre": "Cold fusion (Fleischmann-Pons)",
        "claim": (
            "La fusión nuclear ocurre a temperatura ambiente en electrodos de paladio "
            "sumergidos en agua pesada. El paladio absorbe deuterio hasta saturación, "
            "forzando la fusión D+D -> He-4 + energía. Predicción: se observará exceso de calor, "
            "emisión de neutrones, y producción de tritio. El exceso de calor es proporcional "
            "a la corriente aplicada."
        ),
        "esperado": 0,
    },
    {
        "nombre": "Relatividad General (claims básicos)",
        "claim": (
            "La gravedad es la curvatura del espacio-tiempo descrita por la métrica g_mu_nu. "
            "La ecuación de campo es G_mu_nu = 8*pi*G*T_mu_nu / c^4. "
            "Predicción: la luz se desvía 1.75 arcosegundos cerca del Sol durante un eclipse. "
            "El perihelio de Mercurio precesa 43 arcoseg/centenario. "
            "El tiempo se dilata en campos gravitacionales (Pound-Rebka). "
            "Los pulsares binarios emiten ondas gravitacionales (Hulse-Taylor, LIGO). "
            "Las observaciones de S2 cerca de Sgr A* confirman precesión relativista."
        ),
        "esperado": 5,
    },
    {
        "nombre": "Mochizuki ABC proof (sin aceptar)",
        "claim": (
            "La conjetura abc en teoría de números establece que para tres enteros coprimos "
            "a, b, c con a+b=c, el radical rad(abc) es casi siempre mayor que c^(1-epsilon). "
            "Mochizuki probó esta conjetura usando Inter-universal Teichmüller theory. "
            "Predicción: la prueba contiene nuevas estructuras matemáticas que generalizan "
            "la geometría aritmética. La prueba no produce predicciones cuantitativas numéricas."
        ),
        "esperado": 2,
    },
]


def run_test_suite(llm_caller=None, use_cache: bool = False):
    """Ejecuta todos los tests. Devuelve lista de resultados.

    Por defecto, desactiva caché para forzar re-ejecución de agentes.
    """
    results = []
    for case in HISTORICAL_CASES:
        print(f"\n[TEST] {case['nombre']} (esperado nivel {case['esperado']})",
              file=sys.stderr)
        t0 = time.time()
        try:
            v = audit(case["claim"], llm_caller=llm_caller,
                     modelo="test-suite",
                     use_cache=use_cache,
                     similarity_threshold=0.0)  # no usar similaridad en tests
            elapsed = time.time() - t0
            actual = v.nivel
            esperado = case["esperado"]
            if esperado == 0:
                passed = actual <= 1
            elif esperado == 5:
                passed = actual >= 3
            else:
                passed = abs(actual - esperado) <= 1
            results.append({
                "nombre": case["nombre"],
                "claim_id": v.claim_id,
                "esperado": esperado,
                "actual": actual,
                "r_score": v.r_score,
                "elapsed": round(elapsed, 1),
                "pass": passed,
                "veredicto": v,
            })
            status = "PASS" if passed else "FAIL"
            print(f"  -> {status}: actual={actual} (R={v.r_score}) en {elapsed:.1f}s",
                  file=sys.stderr)
        except Exception as e:
            print(f"  -> ERROR: {e}", file=sys.stderr)
            results.append({
                "nombre": case["nombre"],
                "claim_id": "?",
                "esperado": case["esperado"],
                "actual": -1,
                "r_score": 0.0,
                "elapsed": 0.0,
                "pass": False,
                "veredicto": None,
            })
    return results


def test_memory_caching():
    """Test específico de memoria: segunda llamada debe ser instantánea."""
    print("\n[TEST MEMORIA] Re-auditar mismo claim debe usar caché", file=sys.stderr)
    claim = HISTORICAL_CASES[0]["claim"]

    # Primera auditoría (no cacheada)
    t0 = time.time()
    v1 = audit(claim, modelo="memory-test", use_cache=False, similarity_threshold=0.0)
    t1 = time.time() - t0

    # Segunda auditoría (debe usar caché)
    t0 = time.time()
    v2 = audit(claim, modelo="memory-test", use_cache=True, similarity_threshold=0.0)
    t2 = time.time() - t0

    speedup = t1 / t2 if t2 > 0 else float('inf')
    cached = v2.cached
    same_level = v1.nivel == v2.nivel

    print(f"  Primera: {t1:.2f}s, nivel={v1.nivel}", file=sys.stderr)
    print(f"  Segunda: {t2:.2f}s, nivel={v2.nivel}, cached={cached}", file=sys.stderr)
    print(f"  Speedup: {speedup:.1f}x", file=sys.stderr)

    return {
        "pass": cached and same_level,
        "speedup": round(speedup, 1),
        "t_first": round(t1, 2),
        "t_cached": round(t2, 2),
    }


if __name__ == "__main__":
    # Limpiar DB antes de empezar para tests reproducibles
    if DB_PATH.exists():
        DB_PATH.unlink()

    results = run_test_suite(use_cache=False)
    n_pass = sum(1 for r in results if r["pass"])
    n_total = len(results)
    print()
    print("=" * 70)
    print(f"TEST SUMMARY (precisión): {n_pass}/{n_total} casos correctos")
    print(f"  (tolerancia ±1 nivel para casos frontera)")
    for r in results:
        status = "PASS" if r["pass"] else "FAIL"
        print(f"  [{status}] esperado={r['esperado']} actual={r['actual']} "
              f"(R={r['r_score']:.3f}, {r['elapsed']}s) — {r['nombre'][:50]}")

    print()
    print("=" * 70)
    print("TEST MEMORIA (cache hit)")
    mem = test_memory_caching()
    if mem["pass"]:
        print(f"  PASS — speedup {mem['speedup']}x ({mem['t_first']}s → {mem['t_cached']}s)")
    else:
        print(f"  FAIL — speedup {mem['speedup']}x")

    print()
    precision = n_pass / n_total if n_total > 0 else 0.0
    print(f"PRECISIÓN: {precision:.1%}")
    if precision < 0.70:
        print("FAIL: Precisión < 70% — proyecto debe abortar antes de beta.")
        sys.exit(1)
    else:
        print("OK: Precisión >= 70% — proyecto puede pasar a F2.")


# ============================================================
#          TESTS UNITARIOS v3.2 (pytest) — agentes nuevos
# ============================================================

def _mkclaim(texto, eqs=None):
    from deces import Claim
    return Claim(raw_input=texto, dominio="fisica", premisas=[], predicciones=[],
                 supuestos_implicitos=[], marcos_competidores=[],
                 ecuaciones=eqs or [])


def test_a1plus_caza_bug_dimensional_tau_s():
    """A1+ debe detectar que tau_S = 1/(alpha*c*N_dot_e) tiene unidades s^2/m."""
    from deces import agente_a1plus_dimensional
    r = agente_a1plus_dimensional(_mkclaim("t", ["tau_S = 1/(alpha*c*N_dot_e)"]))
    assert any("dimensional" in o["text"].lower() for o in r.objections)
    assert r.score < 1.0 and not r.abstained


def test_a1plus_acepta_ecuacion_correcta_y_se_abstiene_sin_ecuaciones():
    from deces import agente_a1plus_dimensional
    ok = agente_a1plus_dimensional(_mkclaim("t", ["delta_t = r_s/c"]))
    assert ok.score == 1.0 and not ok.objections
    vacio = agente_a1plus_dimensional(_mkclaim("sin ecuaciones"))
    assert vacio.abstained


def test_a7_caza_los_tres_bugs_reales_de_tcr():
    from deces import agente_a7_consistencia
    r1 = agente_a7_consistencia(_mkclaim(
        "El reloj opera a 1.08x la cota, aproximandose al limite."))
    assert any(o["source"] == "A7-ratio-invertido" for o in r1.objections)
    r2 = agente_a7_consistencia(_mkclaim("El cierre da 1.000000 universal."))
    assert any(o["source"] == "A7-identidad" for o in r2.objections)
    r3 = agente_a7_consistencia(_mkclaim("Se requiere beta_1 = 10^-54."))
    assert any(o["source"] == "A7-conteo-menor-1" for o in r3.objections)
    silencio = agente_a7_consistencia(_mkclaim("Texto sin numeros sospechosos."))
    assert silencio.abstained


def test_integrador_fatal_y_abstencion():
    from deces import integrar, AgentReport
    c = _mkclaim("x")
    fatal = AgentReport("A4", "E", "t", 0.0,
                        [{"severity": "alta", "text": "x", "source": "y"}], [],
                        is_fatal=True)
    ok = AgentReport("A1", "L", "t", 1.0, [], [])
    for metodo in ("geometrico", "ponderado"):
        v = integrar([fatal, ok], c, metodo=metodo)
        assert v.nivel == 0 and v.r_score == 0.0
    # abstencion: un 1.0 abstenido NO debe subir el veredicto
    bajo = AgentReport("A4", "E", "t", 0.4,
                       [{"severity": "media", "text": "x", "source": "y"}], [])
    abst = AgentReport("A7", "C", "t", 1.0, [], [], abstained=True)
    v_sin = integrar([bajo], c, metodo="geometrico")
    v_con = integrar([bajo, abst], c, metodo="geometrico")
    assert abs(v_sin.r_score - v_con.r_score) < 1e-9


def test_ponderado_no_es_default_y_cero_nofatal_colapsa_en_geometrico():
    from deces import integrar, AgentReport, INTEGRADOR_DEFAULT
    assert INTEGRADOR_DEFAULT == "geometrico"
    c = _mkclaim("x")
    cero = AgentReport("A3", "F", "t", 0.0,
                       [{"severity": "media", "text": "sin predicciones",
                         "source": "A3"}], [])
    resto = [AgentReport(a, "n", "t", 0.9, [], [])
             for a in ("A1", "A2", "A4", "A5", "A6")]
    v = integrar([cero] + resto, c, metodo="geometrico")
    assert v.nivel == 0

# Claudio Coding Workbench proposed local note
# Objective: Arregla la funcion test_memory_caching en test_deces.py: pytest advierte PytestReturnNotNoneWarning porque el test hace 'return' de un dict. Debe terminar con asserts (p.ej. assert speedup >= 10) y NO retornar nada. Conserva toda la logica 
