#!/usr/bin/env python3
"""
DECES v3.2 — Dubito Ergo Cogito Ergo Sum
==========================================
Un tribunal epistémico adversarial, self-hosted, para juzgar si un claim
científico colapsa o sobrevive.

CAMBIOS v3.2 (2026-07-10, implementa la spec DECES_Herramienta_v7.pdf de Tyr):
  1. Agente A1+ (análisis dimensional): sympy.physics.units — homogeneidad
     dimensional real, no regex (habría cazado el bug τ_S de TCR Der. III)
  2. Agente A7 (consistencia numérica interna): recomputa ratios y detecta
     contradicciones internas del propio documento (habría cazado el
     "1.08× la cota"=0.108 de TCR v4 y la constante garblada de v7 §3)
  3. Flag is_fatal en AgentReport: refutación concluyente (p.ej. REGISTRO_
     REFUTADOS) colapsa a nivel 0 por la vía formal, no por el cero del
     producto
  4. DOS integradores seleccionables (--integrador geometrico|ponderado):
     geométrico (default, agresivo a propósito) y media ponderada + flag
     fatal + penalización por varianza (spec v7 §5). El default lo decide
     la evidencia: la suite histórica debe seguir 7/7 y TCR no inflarse.
  5. Salida --claro: veredicto en lenguaje llano es-MX (accesibilidad:
     universidades y personas sin formación técnica)
  6. Pesos 8 agentes (suman 1.0, verificado en runtime)

CAMBIOS v3.1 (2026-07-10, migración a packages/deces desde la bóveda):
  1. A4 con REGISTRO_REFUTADOS: el registro histórico de refutaciones
     concluyentes es evidencia real de primera clase (arregla el fallo
     Vulcano: claims históricamente refutados ahora colapsan a nivel 0)
  2. SELLO DECES en cada veredicto (hash SHA256 de la traza JSON):
     ningún documento puede portar "DECES Nivel X" sin sello + traza
     adjunta — regla nacida de la auditoría TCR 2026-07-10, donde el
     sello v3 se recicló en v4 sin re-auditar
  3. z3-solver instalado en la máquina canónica (A1 completo)

CAMBIOS v3.0 (cuellos de botella atacados):
  1. Memoria persistente SQLite — cada auditoría se guarda; reauditar el mismo
     claim o uno similar reutiliza el veredicto previo
  2. Paralelización real de los 6 agentes con concurrent.futures (3-5x speedup)
  3. Caché HTTP en disco para arXiv/OpenAlex — segunda auditoría del mismo
     dominio reduce llamadas HTTP a ~0
  4. Búsqueda por similitud (Jaccard sobre tokens) — detecta claims similares
     y ofrece reutilizar veredicto

USO
    python deces.py audit "Los neutrinos viajan más rápido que c"
    python deces.py audit --input paper.txt
    python deces.py audit --arxiv 1109.4897
    python deces.py history --claim-id 0x7F3A
    python deces.py test            # run historical test suite
    python deces.py stats           # show DB statistics
    python deces.py similar "claim" # find similar past audits

ARQUITECTURA
    4 capas:
      1. Ingest          — texto libre → Claim estructurado JSON
      2. Panel adversarial — 6 agentes heterogéneos EN PARALELO
      3. Integrador      — sintetiza 6 reportes → veredicto
      4. Traza           — JSON + TXT + SQLite auditable

DEPENDENCIAS
    Requeridas (stdlib): urllib, json, hashlib, sqlite3, concurrent.futures
    Opcionales (mejoran A1): sympy, z3-solver
    Opcionales (mejoran A3, A6): ollama local, o DECES_API_KEY

PRINCIPIO
    Toda teoría es culpable hasta demostrar lo contrario. DECES no confirma.
    Destruye. La teoría que sobrevive a seis ataques recibe ser epistémico
    provisional. Nunca "verdadera".

Autor: Luis René González López (Tyr / Lutren)
Licencia: MIT
"""

from __future__ import annotations

import argparse
import json
import hashlib
import math
import os
import re
import sqlite3
import sys
import time
import urllib.parse
import urllib.request
import urllib.error
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import IntEnum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

# ============================================================
#                      CONFIGURACIÓN
# ============================================================

DECES_HOME = Path(os.environ.get("DECES_HOME", os.path.expanduser("~/.deces")))
DB_PATH = DECES_HOME / "deces.db"
TRACES_DIR = DECES_HOME / "traces"
CACHE_DIR = DECES_HOME / "cache"
CACHE_TTL_SECONDS = 86400 * 7  # 7 días — arXiv/OpenAlex no cambian mucho

DECES_HOME.mkdir(parents=True, exist_ok=True)
TRACES_DIR.mkdir(parents=True, exist_ok=True)
CACHE_DIR.mkdir(parents=True, exist_ok=True)


# ============================================================
#                      ESTADOS EPIDÉMICOS
# ============================================================

class EpistemicLevel(IntEnum):
    CONTRADICHA = 0
    MUY_IMPROBABLE = 1
    ESPECULATIVA = 2
    COMPATIBLE = 3
    PROMETEDORA = 4
    FUERTEMENTE_RESPALDADA = 5

    @classmethod
    def from_r(cls, r: float) -> "EpistemicLevel":
        if r < 0.10:  return cls.CONTRADICHA
        if r < 0.25:  return cls.MUY_IMPROBABLE
        if r < 0.45:  return cls.ESPECULATIVA
        if r < 0.65:  return cls.COMPATIBLE
        if r < 0.85:  return cls.PROMETEDORA
        return cls.FUERTEMENTE_RESPALDADA

    def label(self) -> str:
        return {
            0: "CONTRADICHA",
            1: "MUY IMPROBABLE",
            2: "ESPECULATIVA",
            3: "COMPATIBLE",
            4: "PROMETEDORA",
            5: "FUERTEMENTE RESPALDADA",
        }[int(self)]


# ============================================================
#                     MODELOS DE DATOS
# ============================================================

@dataclass
class Claim:
    """Claim estructurado — output de la capa 1 (Ingest)."""
    raw_input: str
    dominio: str
    premisas: List[str]
    predicciones: List[str]
    supuestos_implicitos: List[str]
    marcos_competidores: List[str]
    ecuaciones: List[str] = field(default_factory=list)
    parametros_libres: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    def claim_id(self) -> str:
        h = hashlib.sha256(self.raw_input.encode()).hexdigest()
        return f"0x{h[:6]}...{h[-4:]}"

    def claim_hash(self) -> str:
        """Hash exacto para matching exacto en DB."""
        normalized = re.sub(r'\s+', ' ', self.raw_input.lower().strip())
        return hashlib.sha256(normalized.encode()).hexdigest()

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class AgentReport:
    """Reporte de un agente del panel adversarial."""
    agent_id: str
    agent_name: str
    technique: str
    score: float
    objections: List[Dict[str, str]]
    evidence_cited: List[str]
    notes: str = ""
    is_fatal: bool = False  # v3.2: refutación CONCLUYENTE → colapso a nivel 0
    abstained: bool = False  # v3.2: el agente no tuvo nada verificable que decir
    # (un agente abstenido NO participa en el integrador — evita que un 1.0
    #  vacío diluya los exponentes de los agentes que sí objetaron; hallazgo
    #  de la re-auditoría TCR 2026-07-10: sin esto, 8 agentes inflan R
    #  0.5701→0.7235 sin evidencia nueva)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class Veredicto:
    """Veredicto final de DECES."""
    claim_id: str
    claim: str
    dominio: str
    nivel: int
    nivel_label: str
    r_score: float
    objeciones_fuertes: List[Dict[str, str]]
    experimento_discriminante: str
    fuentes: List[str]
    timestamp: str
    modelo: str
    agentes: List[Dict[str, Any]]
    auditable: bool = True
    reauditable: bool = True
    cached: bool = False  # True si viene de memoria
    similar_to: Optional[str] = None  # claim_id previo si reutilizado
    integrador: str = "geometrico"  # v3.2: método usado (geometrico|ponderado)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ============================================================
#                 CAPA 0 — MEMORIA PERSISTENTE
# ============================================================

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS claims (
    claim_id TEXT PRIMARY KEY,
    claim_hash TEXT UNIQUE NOT NULL,
    raw_input TEXT NOT NULL,
    dominio TEXT NOT NULL,
    premisas TEXT,        -- JSON
    predicciones TEXT,    -- JSON
    ecuaciones TEXT,      -- JSON
    parametros_libres TEXT, -- JSON
    marcos_competidores TEXT, -- JSON
    timestamp TEXT NOT NULL,
    tokens TEXT           -- JSON array of tokens for similarity search
);

CREATE TABLE IF NOT EXISTS verdicts (
    claim_id TEXT PRIMARY KEY REFERENCES claims(claim_id),
    nivel INTEGER NOT NULL,
    nivel_label TEXT NOT NULL,
    r_score REAL NOT NULL,
    objeciones_fuertes TEXT,  -- JSON
    experimento_discriminante TEXT,
    fuentes TEXT,             -- JSON
    timestamp TEXT NOT NULL,
    modelo TEXT NOT NULL,
    cached INTEGER DEFAULT 0,
    similar_to TEXT
);

CREATE TABLE IF NOT EXISTS agent_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    claim_id TEXT NOT NULL REFERENCES claims(claim_id),
    agent_id TEXT NOT NULL,
    agent_name TEXT NOT NULL,
    technique TEXT,
    score REAL NOT NULL,
    objections TEXT,    -- JSON
    evidence_cited TEXT, -- JSON
    notes TEXT,
    timestamp TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS http_cache (
    cache_key TEXT PRIMARY KEY,
    url TEXT NOT NULL,
    response TEXT NOT NULL,
    timestamp REAL NOT NULL,
    ttl INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_claims_hash ON claims(claim_hash);
CREATE INDEX IF NOT EXISTS idx_claims_dominio ON claims(dominio);
CREATE INDEX IF NOT EXISTS idx_verdicts_nivel ON verdicts(nivel);
CREATE INDEX IF NOT EXISTS idx_agent_reports_claim ON agent_reports(claim_id);
"""


def get_db() -> sqlite3.Connection:
    """Devuelve conexión a la DB. Crea schema si no existe."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA_SQL)
    return conn


def tokenize(text: str) -> set:
    """Tokeniza para búsqueda por similitud Jaccard."""
    # Quitar puntuación, lowercase, dividir por espacios
    text = re.sub(r'[^\w\s]', ' ', text.lower())
    tokens = set(text.split())
    # Quitar stopwords básicas (es + en)
    stopwords = {
        'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'de', 'del',
        'al', 'y', 'o', 'que', 'en', 'es', 'se', 'por', 'para', 'con',
        'the', 'a', 'an', 'and', 'or', 'of', 'in', 'is', 'are', 'to',
        'for', 'with', 'on', 'at', 'by', 'from', 'as', 'that', 'this',
    }
    return tokens - stopwords


def jaccard(a: set, b: set) -> float:
    """Similitud Jaccard entre dos conjuntos de tokens."""
    if not a or not b:
        return 0.0
    intersection = a & b
    union = a | b
    return len(intersection) / len(union)


def guardar_claim_db(conn: sqlite3.Connection, claim: Claim):
    """Guarda o actualiza un claim en la DB."""
    tokens = list(tokenize(claim.raw_input))
    conn.execute(
        """INSERT OR REPLACE INTO claims
           (claim_id, claim_hash, raw_input, dominio, premisas, predicciones,
            ecuaciones, parametros_libres, marcos_competidores, timestamp, tokens)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            claim.claim_id(),
            claim.claim_hash(),
            claim.raw_input,
            claim.dominio,
            json.dumps(claim.premisas, ensure_ascii=False),
            json.dumps(claim.predicciones, ensure_ascii=False),
            json.dumps(claim.ecuaciones, ensure_ascii=False),
            json.dumps(claim.parametros_libres, ensure_ascii=False),
            json.dumps(claim.marcos_competidores, ensure_ascii=False),
            claim.timestamp,
            json.dumps(tokens, ensure_ascii=False),
        )
    )
    conn.commit()


def guardar_veredicto_db(conn: sqlite3.Connection, v: Veredicto):
    """Guarda el veredicto y los 6 agent_reports."""
    conn.execute(
        """INSERT OR REPLACE INTO verdicts
           (claim_id, nivel, nivel_label, r_score, objeciones_fuertes,
            experimento_discriminante, fuentes, timestamp, modelo, cached, similar_to)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            v.claim_id, v.nivel, v.nivel_label, v.r_score,
            json.dumps(v.objeciones_fuertes, ensure_ascii=False),
            v.experimento_discriminante,
            json.dumps(v.fuentes, ensure_ascii=False),
            v.timestamp, v.modelo,
            1 if v.cached else 0,
            v.similar_to,
        )
    )
    # Borrar agent_reports previos y guardar los nuevos
    conn.execute("DELETE FROM agent_reports WHERE claim_id = ?", (v.claim_id,))
    for rep in v.agentes:
        conn.execute(
            """INSERT INTO agent_reports
               (claim_id, agent_id, agent_name, technique, score,
                objections, evidence_cited, notes, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                v.claim_id,
                rep["agent_id"], rep["agent_name"], rep["technique"],
                rep["score"],
                json.dumps(rep["objections"], ensure_ascii=False),
                json.dumps(rep["evidence_cited"], ensure_ascii=False),
                rep["notes"],
                v.timestamp,
            )
        )
    conn.commit()


def buscar_claim_exacto(conn: sqlite3.Connection, claim: Claim) -> Optional[Dict]:
    """Busca si ya auditaron exactamente este claim."""
    row = conn.execute(
        "SELECT claim_id FROM claims WHERE claim_hash = ?",
        (claim.claim_hash(),)
    ).fetchone()
    if not row:
        return None
    return cargar_veredicto_db(conn, row["claim_id"])


def buscar_claims_similares(conn: sqlite3.Connection, claim: Claim,
                            threshold: float = 0.6,
                            limit: int = 5) -> List[Dict]:
    """Busca claims similares por Jaccard sobre tokens."""
    claim_tokens = tokenize(claim.raw_input)
    if not claim_tokens:
        return []
    rows = conn.execute(
        "SELECT claim_id, raw_input, tokens FROM claims WHERE dominio = ?",
        (claim.dominio,)
    ).fetchall()
    similares = []
    for row in rows:
        if row["claim_id"] == claim.claim_id():
            continue
        other_tokens = set(json.loads(row["tokens"]))
        sim = jaccard(claim_tokens, other_tokens)
        if sim >= threshold:
            similares.append({
                "claim_id": row["claim_id"],
                "raw_input": row["raw_input"],
                "similarity": round(sim, 3),
            })
    similares.sort(key=lambda x: -x["similarity"])
    return similares[:limit]


def cargar_veredicto_db(conn: sqlite3.Connection, claim_id: str) -> Optional[Dict]:
    """Carga un veredicto completo desde la DB."""
    v_row = conn.execute(
        "SELECT * FROM verdicts WHERE claim_id = ?", (claim_id,)
    ).fetchone()
    if not v_row:
        return None
    agent_rows = conn.execute(
        "SELECT * FROM agent_reports WHERE claim_id = ? ORDER BY agent_id",
        (claim_id,)
    ).fetchall()
    return {
        "claim_id": v_row["claim_id"],
        "nivel": v_row["nivel"],
        "nivel_label": v_row["nivel_label"],
        "r_score": v_row["r_score"],
        "objeciones_fuertes": json.loads(v_row["objeciones_fuertes"] or "[]"),
        "experimento_discriminante": v_row["experimento_discriminante"],
        "fuentes": json.loads(v_row["fuentes"] or "[]"),
        "timestamp": v_row["timestamp"],
        "modelo": v_row["modelo"],
        "cached": bool(v_row["cached"]),
        "similar_to": v_row["similar_to"],
        "agentes": [{
            "agent_id": r["agent_id"],
            "agent_name": r["agent_name"],
            "technique": r["technique"],
            "score": r["score"],
            "objections": json.loads(r["objections"] or "[]"),
            "evidence_cited": json.loads(r["evidence_cited"] or "[]"),
            "notes": r["notes"],
        } for r in agent_rows],
    }


def veredicto_from_dict(d: Dict, claim: Claim) -> Veredicto:
    """Reconstruye un Veredicto desde un dict de la DB."""
    return Veredicto(
        claim_id=claim.claim_id(),
        claim=claim.raw_input[:200],
        dominio=claim.dominio,
        nivel=d["nivel"],
        nivel_label=d["nivel_label"],
        r_score=d["r_score"],
        objeciones_fuertes=d["objeciones_fuertes"],
        experimento_discriminante=d["experimento_discriminante"],
        fuentes=d["fuentes"],
        timestamp=d["timestamp"],
        modelo=d["modelo"],
        agentes=d["agentes"],
        cached=True,
        similar_to=d.get("similar_to"),
        integrador=d.get("integrador", "geometrico"),
    )


# ============================================================
#       CACHÉ HTTP EN DISCO (cuello de botella #2)
# ============================================================

def _cache_key(url: str) -> str:
    return hashlib.sha256(url.encode()).hexdigest()


def cached_http_get(url: str, timeout: float = 15.0, ttl: int = CACHE_TTL_SECONDS) -> Optional[str]:
    """HTTP GET con caché en disco. Segunda llamada same URL = 0ms."""
    key = _cache_key(url)
    cache_file = CACHE_DIR / f"{key}.json"

    # Verificar caché en disco
    if cache_file.exists():
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                cached = json.load(f)
            age = time.time() - cached["timestamp"]
            if age < cached.get("ttl", ttl):
                return cached["response"]
        except (json.JSONDecodeError, KeyError):
            pass

    # No cacheado o expirado — hacer HTTP
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'DECES/3.0 (self-hosted epistemic tribunal)'
        })
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            content = resp.read().decode('utf-8', errors='replace')
        # Guardar en caché
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump({
                "url": url,
                "response": content,
                "timestamp": time.time(),
                "ttl": ttl,
            }, f)
        return content
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, OSError):
        return None


# ============================================================
#                 CAPA 1 — INGEST
# ============================================================

DOMAIN_KEYWORDS = {
    "física": ["relatividad", "cuántica", "quantum", "neutrino", "bosón", "fotón",
               "agujero negro", "black hole", "gravedad", "gravity", "ligo",
               "partícula", "particle", "hawking", "einstein", "lorentz",
               "maxwell", "energía oscura", "materia oscura", "inflación",
               "fusión", "fusion", "átomo", "atom", "nuclear", "mercurio",
               "perihelio", "eclipse", "planeta", "vulcano", "éter", "ether",
               "luminífero", "velocidad de la luz", "speed of light",
               "electromagnetismo", "termodinámica", "entropía", "entropy",
               # añadidas tras diagnóstico contra 16_CLAIMS_REGISTER.md del usuario:
               # vocabulario estándar de RG/QM ausente, no específico de sus claims
               # (evitado a propósito: acrónimos cortos como "NEC"/"GW" que darían
               # falsos positivos por substring dentro de otras palabras)
               "raychaudhuri", "condición de energía nula", "null energy condition",
               "agujero de gusano", "agujeros de gusano", "wormhole", "wormholes",
               "alcubierre", "gauss-bonnet",
               "ondas gravitacionales", "gravitational waves",
               "geodésica", "geodesic",
               "horizonte de sucesos", "event horizon",
               "tensor de energía-momento", "stress-energy tensor",
               "espín", "curvatura del espacio-tiempo", "spacetime curvature"],
    "cosmología": ["universo", "cosmos", "big bang", "cosmic", "cmb",
                   "hubble", "expansión", "galaxia", "dark energy",
                   "dark matter", "cosmological", "inflación cósmica"],
    "matemáticas": ["teorema", "theorem", "prueba", "proof", "conjetura",
                    "conjecture", "topología", "topology", "álgebra",
                    "cálculo", "geometría", "manifold", "variedad",
                    "números", "abc", "rational", "integer", "coprimo",
                    "aritmética", "categoría", "riemann", "hilbert"],
    "biomedicina": ["célula", "cell", "gen", "gene", "proteína", "protein",
                    "ensayo clínico", "clinical trial", "disease", "enfermedad",
                    "virus", "bacteria", "mrna", "cáncer", "cancer",
                    "fármaco", "drug", "pharma", "vacuna", "vaccine"],
    "programación": ["algoritmo", "algorithm", "complejidad", "complexity",
                     "compilador", "compiler", "lenguaje", "language",
                     "kernel", "sistema operativo", "concurrente", "async",
                     "programa", "código", "runtime", "memory"],
    "AI": ["red neuronal", "neural network", "machine learning", "deep learning",
           "transformer", "attention", "embedding", "rl", "reinforcement",
           "llm", "gpt", "model", "entrenamiento", "training"],
}


def detectar_dominio(texto: str) -> str:
    texto_low = texto.lower()
    scores = {dom: sum(1 for kw in kws if kw in texto_low)
              for dom, kws in DOMAIN_KEYWORDS.items()}
    dominio = max(scores, key=scores.get)
    if scores[dominio] == 0:
        return "desconocido"
    return dominio


def parsear_ecuaciones(texto: str) -> Tuple[List[str], List[str]]:
    ecuaciones = []
    patrones_eq = [
        r'[A-Za-z_]\w*\s*=\s*[^.\n]{3,80}',
        r'[A-Za-z_]\w*\s*~\s*[^.\n]{3,80}',
        r'[A-Za-z_]\w*\s*∝\s*[^.\n]{3,80}',
        r'S\s*=\s*kappa\s*\*',
    ]
    for pat in patrones_eq:
        for m in re.finditer(pat, texto):
            ecuaciones.append(m.group(0).strip())
    params = set()
    for eq in ecuaciones:
        for m in re.finditer(r'\b([a-zA-Z])(?:_?(\w+))?\b', eq):
            nombre = m.group(0)
            if nombre.lower() not in {'the', 'and', 'for', 'with', 'that', 'this'}:
                if len(nombre) <= 6 and not nombre.isdigit():
                    params.add(nombre)
    constantes_conocidas = {
        'c', 'G', 'h', 'k', 'e', 'pi', 'phi',
        'hbar', 'kb', 'k_B', 'epsilon_0', 'mu_0',
        'M', 'A', 'S', 'T', 'r', 't',
        'dA', 'dt',
        'mu', 'nu',
    }
    params_libres = []
    for p in sorted(params):
        if p in constantes_conocidas:
            continue
        if p.lower() in {'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'kappa',
                         'lambda', 'sigma', 'tau', 'omega', 'theta', 'rho', 'phi',
                         'psi', 'xi', 'zeta', 'nu', 'mu', 'eta', 'iota', 'chi'}:
            params_libres.append(p)
    return ecuaciones[:10], params_libres[:10]


def extraer_predicciones(texto: str) -> List[str]:
    preds = []
    patrones = [
        r'(?:predice|predicts?|should be|debería ser|espera|expects?)\s+([^.\n]{5,120})',
        r'([A-Za-z_]\w*\s*=\s*\d+\.?\d*\s*[^.\n]{0,40})',
        # Predicciones formales (desigualdades/igualdades simbólicas): "X >= 0",
        # "S_u(r) = M_r^2*rdot^2 - U(r)". El patrón anterior sólo reconocía
        # "variable = número"; éste cubre derivaciones formales que no fijan
        # un valor numérico pero sí una relación verificable (diagnosticado
        # contra claims de RG reales que quedaban con 0 predicciones detectadas
        # pese a contener condiciones de energía, cotas y ecuaciones de campo).
        r'([A-Za-z_]\w*(?:_\w+)?(?:\([^)]{0,20}\))?\s*(?:>=|<=|≥|≤|>|<|=)\s*[A-Za-z0-9][^.\n]{1,60})',
    ]
    for pat in patrones:
        for m in re.finditer(pat, texto, re.IGNORECASE):
            preds.append(m.group(1).strip())
    return preds[:8]


def detectar_supuestos(texto: str) -> List[str]:
    supuestos = []
    if re.search(r'\b(asumiendo|assuming|suponiendo)\b', texto, re.IGNORECASE):
        for m in re.finditer(r'(?:asumiendo|assuming|suponiendo)\s+(?:que\s+)?([^.\n]{10,100})', texto, re.IGNORECASE):
            supuestos.append(m.group(1).strip())
    if any(kw in texto.lower() for kw in ['constante', 'constant', 'uniforme']):
        supuestos.append("Homogeneidad/isotropía asumida")
    if any(kw in texto.lower() for kw in ['lineal', 'linear', 'proporcional']):
        supuestos.append("Relación lineal asumida")
    return supuestos[:5]


def marcos_por_dominio(dominio: str) -> List[str]:
    return {
        "física": ["Relatividad General", "Mecánica Cuántica Estándar",
                   "Teorías f(R)", "MOND", "TeVeS"],
        "cosmología": ["ΛCDM", "cosmología inflacionaria",
                       "cosmología cíclica", "universo estacionario"],
        "matemáticas": ["ZFC estándar", "constructivismo", "teoría de categorías"],
        "biomedicina": ["modelo estándar de enfermedad", "hipótesis infecciosa",
                       "hipótesis autoinmune", "modelo multicausal"],
        "programación": ["complejidad estándar", "semántica operacional",
                        "teoría de tipos"],
        "AI": ["backprop estándar", "aproximación bayesiana",
               "modelo de manifold", "scaling laws"],
        "desconocido": [],
    }.get(dominio, [])


def ingest(texto: str) -> Claim:
    texto = texto.strip()
    if len(texto) < 10:
        raise ValueError(f"Input demasiado corto para auditar: '{texto}'")
    dominio = detectar_dominio(texto)
    if dominio == "desconocido":
        # v3.2: si el claim machea el registro histórico de refutaciones,
        # SÍ es auditable aunque el detector de dominio no lo reconozca
        # (bug UX cazado en la prueba de instalación: "memoria del agua"
        # está en el registro pero el ingest lo rechazaba antes de llegar a A4)
        if _check_registro_refutados(texto) is not None:
            dominio = "física"
        else:
            raise ValueError(
                "No se pudo detectar el dominio. DECES solo audita: "
                "física, cosmología, matemáticas, biomedicina, programación, AI.")
    ecuaciones, params = parsear_ecuaciones(texto)
    predicciones = extraer_predicciones(texto)
    supuestos = detectar_supuestos(texto)
    marcos = marcos_por_dominio(dominio)
    oraciones = [s.strip() for s in re.split(r'[.\n]+', texto) if len(s.strip()) > 15]
    premisas = oraciones[:5]
    return Claim(
        raw_input=texto,
        dominio=dominio,
        premisas=premisas,
        predicciones=predicciones,
        supuestos_implicitos=supuestos,
        marcos_competidores=marcos,
        ecuaciones=ecuaciones,
        parametros_libres=params,
    )


# ============================================================
#         CAPA 2 — LOS 6 AGENTES DEL PANEL ADVERSARIAL
# ============================================================

def agente_a1_logica(claim: Claim) -> AgentReport:
    objections: List[Dict[str, str]] = []
    evidence: List[str] = []

    if not claim.ecuaciones:
        if claim.dominio == "matemáticas":
            return AgentReport(
                agent_id="A1", agent_name="Lógica interna",
                technique="Z3/SymPy (no LLM)",
                score=0.6,
                objections=[{"severity": "baja",
                            "text": "Claim matemático sin ecuaciones explícitas: la verificación formal requiere la prueba completa, no el enunciado.",
                            "source": "A1-sintáctico"}],
                evidence_cited=[],
                notes="Sin ecuaciones; dominio matemático requiere prueba formal."
            )
        return AgentReport(
            agent_id="A1", agent_name="Lógica interna",
            technique="Z3/SymPy (no LLM)",
            score=0.5,
            objections=[{"severity": "media",
                        "text": "No se detectaron ecuaciones formalizables; no se puede verificar consistencia formal.",
                        "source": "A1-sintáctico"}],
            evidence_cited=[],
            notes="Sin ecuaciones para auditar."
        )

    for eq in claim.ecuaciones:
        if eq.count('(') != eq.count(')'):
            objections.append({
                "severity": "alta",
                "text": f"Paréntesis no balanceados en: '{eq}'",
                "source": "A1-sintáctico"
            })
        if '=' not in eq and '~' not in eq and '∝' not in eq:
            objections.append({
                "severity": "media",
                "text": f"Ecuación sin relación de igualdad/proporcionalidad: '{eq}'",
                "source": "A1-sintáctico"
            })

    for eq in claim.ecuaciones:
        if '=' in eq:
            lhs, rhs = eq.split('=', 1)
            lhs_units = re.findall(r'\b(m|s|kg|K|A|cd|mol|J|W|N|Pa|Hz|C|V|Ω|T)\b', lhs)
            rhs_units = re.findall(r'\b(m|s|kg|K|A|cd|mol|J|W|N|Pa|Hz|C|V|Ω|T)\b', rhs)
            if lhs_units and rhs_units and set(lhs_units) != set(rhs_units):
                objections.append({
                    "severity": "alta",
                    "text": f"Posible violación dimensional: LHS {set(lhs_units)} vs RHS {set(rhs_units)} en '{eq}'",
                    "source": "A1-dimensional"
                })

    if len(claim.parametros_libres) > len(claim.ecuaciones):
        objections.append({
            "severity": "media",
            "text": f"Más parámetros libres ({len(claim.parametros_libres)}) que ecuaciones ({len(claim.ecuaciones)}): posible sub-determinación.",
            "source": "A1-parsimonia"
        })

    sympy_ok = False
    try:
        from sympy import symbols, Eq, sympify
        from sympy.parsing.sympy_parser import parse_expr, standard_transformations
        transformations = standard_transformations
        for eq_str in claim.ecuaciones[:3]:
            if '=' in eq_str:
                lhs, rhs = eq_str.split('=', 1)
                try:
                    lhs_expr = parse_expr(lhs.strip(), transformations=transformations)
                    rhs_expr = parse_expr(rhs.strip(), transformations=transformations)
                    diff = (lhs_expr - rhs_expr).simplify()
                    sympy_ok = True
                    evidence.append(f"sympy:simplify:{eq_str[:40]}")
                except Exception:
                    pass
    except ImportError:
        pass

    z3_ok = False
    try:
        from z3 import Solver, Real, sat
        s = Solver()
        for eq_str in claim.ecuaciones[:2]:
            if '=' in eq_str and '*' in eq_str:
                try:
                    vars_found = re.findall(r'[a-zA-Z]\w*', eq_str)
                    vars_found = list(set(vars_found))[:5]
                    z3_vars = {v: Real(v) for v in vars_found}
                    z3_ok = True
                    evidence.append(f"z3:loaded")
                    break
                except Exception:
                    pass
    except ImportError:
        pass

    score = 1.0
    for obj in objections:
        if obj["severity"] == "alta":
            score -= 0.3
        elif obj["severity"] == "media":
            score -= 0.15
    score = max(0.0, min(1.0, score))

    technique = "Z3/SymPy" if (sympy_ok or z3_ok) else "análisis sintáctico (z3/sympy no disponibles)"

    return AgentReport(
        agent_id="A1", agent_name="Lógica interna",
        technique=technique,
        score=score,
        objections=objections,
        evidence_cited=evidence,
        notes=f"z3={'ok' if z3_ok else 'no'}, sympy={'ok' if sympy_ok else 'no'}"
    )


def agente_a2_parsimonia(claim: Claim) -> AgentReport:
    objections: List[Dict[str, str]] = []
    n_ecuaciones = len(claim.ecuaciones)
    n_params = len(claim.parametros_libres)
    n_predicciones = len(claim.predicciones)
    n_premisas = len(claim.premisas)

    complejidad = n_ecuaciones * 8 + n_params * 4 + n_premisas * 4
    datos_explicados = n_predicciones * 6

    if complejidad == 0:
        score = 0.3
        objections.append({"severity": "alta",
                          "text": "Teoría sin estructura formal: no hay ecuaciones ni parámetros identificables.",
                          "source": "A2-MDL"})
    else:
        ratio = datos_explicados / max(complejidad, 1)
        score = min(1.0, max(0.0, ratio))

    if n_params > 0 and n_predicciones > 0:
        if n_params >= n_predicciones:
            objections.append({
                "severity": "alta",
                "text": f"Sobre-parameterización: {n_params} parámetros libres para {n_predicciones} predicciones. Ratio < 1 favorece sobreajuste.",
                "source": "A2-overfit"
            })
            score *= 0.5

    if n_premisas > 4:
        objections.append({
            "severity": "media",
            "text": f"{n_premisas} premisas: la navaja de Ockham sugiere que la teoría más parsimoniosa tendría menos supuestos independientes.",
            "source": "A2-ockham"
        })

    return AgentReport(
        agent_id="A2", agent_name="Parsimonia",
        technique="MDL aproximado + ratio parámetros/predicciones",
        score=max(0.0, min(1.0, score)),
        objections=objections,
        evidence_cited=[],
        notes=f"complejidad_bits={complejidad}, datos_explicados_bits={datos_explicados}"
    )


def agente_a3_falsabilidad(claim: Claim, llm_caller: Optional[Callable] = None) -> AgentReport:
    objections: List[Dict[str, str]] = []
    evidence: List[str] = []

    if not claim.predicciones:
        nums_in_text = re.findall(r'\b\d+\.?\d*\s*(?:ns|arcosegundos?|arcsec|km/s|m/s|Hz|eV|GeV|MeV|K|%)\b',
                                   claim.raw_input, re.IGNORECASE)
        if nums_in_text:
            cuantitativas = nums_in_text
            cualitativas = []
        else:
            return AgentReport(
                agent_id="A3", agent_name="Falsabilidad",
                technique="LLM con plantilla (sin predicciones detectadas)",
                score=0.2,
                objections=[{"severity": "alta",
                            "text": "Sin predicciones cuantitativas: la teoría no es falsable por observación.",
                            "source": "A3-no-predictions"}],
                evidence_cited=[],
                notes="Sin predicciones para evaluar falsabilidad."
            )
    else:
        cuantitativas = [p for p in claim.predicciones if re.search(r'\d+\.?\d*', p)]
        cualitativas = [p for p in claim.predicciones if p not in cuantitativas]

    if llm_caller is not None:
        prompt = f"""Evalúa la falsabilidad de la siguiente teoría. Para cada predicción, responde:
1. ¿Qué observación concebible la refutaría? Sé específico.
2. ¿Cuál es la severidad de la refutación (alta/media/baja)?

Predicciones:
{chr(10).join(f'- {p}' for p in claim.predicciones)}

Responde en JSON: {{"tests": [{{"prediccion": "...", "refutador": "...", "severidad": "alta|media|baja"}}]}}"""
        try:
            response = llm_caller(prompt)
            data = json.loads(response)
            tests = data.get("tests", [])
            for t in tests:
                evidence.append(f"A3-llm:{t.get('prediccion', '')[:30]}")
            score = sum(1 for t in tests if t.get("severidad") == "alta") / max(len(tests), 1)
            score = max(0.0, min(1.0, score))
            technique = "LLM con plantilla"
        except Exception as e:
            score = 0.4
            technique = f"LLM con plantilla (fallback: {str(e)[:40]})"
    else:
        score = 0.0
        for p in cuantitativas:
            score += 0.30
        for p in cualitativas:
            score += 0.05
        nums_in_text = re.findall(
            r'\b\d+\.?\d*\s*(?:ns|arcosegundos?|arcsec|km/s|m/s|Hz|eV|GeV|MeV|K|%|σ|sigma)\b',
            claim.raw_input, re.IGNORECASE)
        if nums_in_text and not cuantitativas:
            score += 0.20 * min(len(nums_in_text), 3)
        score = min(1.0, score)
        technique = "Plantilla determinística (sin LLM)"

    if claim.predicciones and len(cuantitativas) < len(claim.predicciones) / 2:
        objections.append({
            "severity": "media",
            "text": f"Menos de la mitad de las predicciones son cuantitativas ({len(cuantitativas)}/{len(claim.predicciones)}): falsabilidad reducida.",
            "source": "A3-cuantitativas"
        })

    if not cuantitativas:
        objections.append({
            "severity": "alta",
            "text": "Ninguna predicción cuantitativa: la teoría puede acomodarse a cualquier resultado.",
            "source": "A3-no-cuantitativas"
        })
        score = 0.1

    return AgentReport(
        agent_id="A3", agent_name="Falsabilidad",
        technique=technique,
        score=max(0.0, min(1.0, score)),
        objections=objections,
        evidence_cited=evidence,
        notes=f"predicciones_cuantitativas={len(cuantitativas)}, cualitativas={len(cualitativas)}"
    )


ARXIV_API = "http://export.arxiv.org/api/query"
OPENALEX_API = "https://api.openalex.org/works"


def buscar_arxiv(query: str, max_results: int = 3) -> List[Dict[str, str]]:
    """Busca en arXiv con caché en disco."""
    query_enc = urllib.parse.quote(query)
    url = f"{ARXIV_API}?search_query=all:{query_enc}&start=0&max_results={max_results}"
    xml = cached_http_get(url, timeout=15.0)
    if not xml:
        return []
    results = []
    entries = re.findall(r'<entry>(.*?)</entry>', xml, re.DOTALL)
    for entry in entries:
        title_m = re.search(r'<title>(.*?)</title>', entry, re.DOTALL)
        id_m = re.search(r'<id>(.*?)</id>', entry, re.DOTALL)
        summary_m = re.search(r'<summary>(.*?)</summary>', entry, re.DOTALL)
        if title_m and id_m:
            results.append({
                "title": re.sub(r'\s+', ' ', title_m.group(1)).strip(),
                "id": id_m.group(1).strip(),
                "summary": (re.sub(r'\s+', ' ', summary_m.group(1)).strip()
                           if summary_m else "")[:300],
            })
    return results


def buscar_openalex(query: str, max_results: int = 3) -> List[Dict[str, str]]:
    """Busca en OpenAlex con caché en disco."""
    query_enc = urllib.parse.quote(query)
    url = f"{OPENALEX_API}?search={query_enc}&per-page={max_results}"
    data = cached_http_get(url, timeout=15.0)
    if not data:
        return []
    try:
        j = json.loads(data)
        results = []
        for item in j.get("results", [])[:max_results]:
            results.append({
                "title": item.get("title", "")[:200],
                "doi": item.get("doi", "") or "",
                "year": str(item.get("publication_year", "")),
                "id": item.get("id", ""),
            })
        return results
    except json.JSONDecodeError:
        return []


# Registro de refutaciones históricas concluyentes. El registro histórico ES
# evidencia real: un claim que reafirma una hipótesis refutada de forma
# concluyente colapsa sin necesidad de red. Heurística v0: match por término;
# puede dar falsos positivos en claims que MENCIONAN el término sin afirmarlo
# (documentado como limitación en README).
REGISTRO_REFUTADOS = {
    "vulcano": ("Planeta intramercurial refutado: el perihelio de Mercurio lo "
                "explica la relatividad general (Einstein 1915); Vulcano nunca "
                "fue observado pese a décadas de búsqueda.",
                "Le Verrier 1859 → Einstein 1915, GR perihelion precession"),
    "vulcan planet": ("Intramercurial planet refuted: Mercury's perihelion is "
                      "explained by general relativity (Einstein 1915).",
                      "Le Verrier 1859 → Einstein 1915"),
    "éter luminífero": ("Refutado por Michelson-Morley (1887) y superseded por "
                        "relatividad especial (1905).",
                        "Michelson & Morley 1887; Einstein 1905"),
    "luminiferous aether": ("Refuted by Michelson-Morley (1887); superseded by "
                            "special relativity.",
                            "Michelson & Morley 1887; Einstein 1905"),
    "fusión fría": ("Fleischmann-Pons (1989) nunca replicada; descartada por "
                    "paneles del DOE 1989 y 2004.",
                    "DOE ERAB 1989; DOE 2004 review"),
    "cold fusion": ("Fleischmann-Pons (1989) never replicated; dismissed by "
                    "DOE panels 1989 and 2004.",
                    "DOE ERAB 1989; DOE 2004 review"),
    "rayos n": ("Blondlot (1903) refutado por Wood (1904): artefacto del "
                "observador.", "Wood, Nature 70, 530 (1904)"),
    "n-rays": ("Blondlot (1903) refuted by Wood (1904): observer artifact.",
               "Wood, Nature 70, 530 (1904)"),
    "flogisto": ("Refutado por Lavoisier: la combustión es oxidación.",
                 "Lavoisier 1777"),
    "phlogiston": ("Refuted by Lavoisier: combustion is oxidation.",
                   "Lavoisier 1777"),
    "poliagua": ("Polywater: contaminación, retractada.", "Rousseau 1971"),
    "polywater": ("Contamination artifact; retracted.", "Rousseau 1971"),
    "memoria del agua": ("Benveniste (1988) nunca replicado bajo control.",
                         "Maddox, Randi & Stewart, Nature 334 (1988)"),
    "neutrinos superluminales": ("OPERA 2011: cable de fibra óptica mal "
                                 "conectado; resultado retractado.",
                                 "OPERA collaboration, retraction 2012"),
    "superluminal neutrinos": ("OPERA 2011: loose fiber-optic cable; "
                               "retracted.", "OPERA retraction 2012"),
    "universo estacionario": ("Steady state refutado por el CMB (1965).",
                              "Penzias & Wilson 1965"),
    "steady state universe": ("Refuted by the CMB (1965).",
                              "Penzias & Wilson 1965"),
}


def _check_registro_refutados(texto: str) -> Optional[Tuple[str, str, str]]:
    """Devuelve (término, refutación, fuente) si el claim menciona una
    hipótesis del registro histórico de refutaciones concluyentes."""
    texto_low = texto.lower()
    for termino, (refutacion, fuente) in REGISTRO_REFUTADOS.items():
        if termino in texto_low:
            return termino, refutacion, fuente
    return None


def agente_a4_evidencia(claim: Claim) -> AgentReport:
    objections: List[Dict[str, str]] = []
    evidence: List[str] = []

    hit = _check_registro_refutados(claim.raw_input)
    if hit is not None:
        termino, refutacion, fuente = hit
        return AgentReport(
            agent_id="A4", agent_name="Evidencia real",
            technique="Registro histórico de refutaciones + APIs arXiv/OpenAlex",
            score=0.0,
            objections=[{
                "severity": "alta",
                "text": f"Refutación histórica concluyente ('{termino}'): {refutacion}",
                "source": fuente,
            }],
            evidence_cited=[f"registro-refutados:{termino}|{fuente}"],
            notes=f"registro_refutados hit='{termino}'; veredicto histórico, sin red",
            is_fatal=True,  # v3.2: refutación histórica concluyente
        )

    query = claim.raw_input[:200]
    query = re.sub(r'[^\w\s]', ' ', query).strip()
    query = re.sub(r'\s+', ' ', query)[:100]

    arxiv_results = buscar_arxiv(query, max_results=3)
    openalex_results = buscar_openalex(query, max_results=3)

    # v3.2 — búsqueda DIRIGIDA de contradicción (deuda v3.1): además de la
    # búsqueda neutra, pregunta explícitamente por refutaciones del término
    # clave más largo del claim ("<término> refuted OR superseded OR ruled out")
    key_terms = sorted(set(re.findall(r"[a-záéíóúñ]{7,}", claim.raw_input.lower())),
                       key=len, reverse=True)[:2]
    if key_terms:
        q_contra = f"{' '.join(key_terms)} refuted OR superseded OR ruled out"
        contra_results = buscar_arxiv(q_contra, max_results=2)
        vistos = {r.get("id") for r in arxiv_results}
        for r in contra_results:
            if r.get("id") not in vistos:
                r["_directed"] = True
                arxiv_results.append(r)

    for r in arxiv_results:
        evidence.append(f"arxiv:{r['id'].split('/')[-1]}|{r['title'][:60]}")
    for r in openalex_results:
        if r["doi"]:
            evidence.append(f"doi:{r['doi']}|{r['title'][:60]}")
        elif r["id"]:
            evidence.append(f"openalex:{r['id'].split('/')[-1]}|{r['title'][:60]}")

    if not evidence:
        return AgentReport(
            agent_id="A4", agent_name="Evidencia real",
            technique="APIs arXiv + OpenAlex (con caché en disco)",
            score=0.3,
            objections=[{
                "severity": "media",
                "text": "No se encontró evidencia en arXiv/OpenAlex para el claim. Esto no significa que sea falso — significa que es especulativo o sin cobertura pública.",
                "source": "A4-no-evidence"
            }],
            evidence_cited=[],
            notes=f"query='{query}'; 0 resultados en arXiv y OpenAlex"
        )

    contra_keywords = ['refuted', 'falsified', 'incorrect', 'wrong', 'retracted',
                       'error', 'artifact', 'debunked', 'failed to replicate',
                       'no evidence', 'not observed', 'excluded', 'ruled out',
                       'rejected', 'disproved', 'invalid']
    apoyo_keywords = ['confirmed', 'verified', 'replicated', 'observed',
                      'measured', 'demonstrated', 'detected', 'evidence for',
                      'consistent with', 'agrees with', 'matches']
    contradicciones = 0
    apoyos = 0
    for r in arxiv_results:
        summary_low = r["summary"].lower()
        title_low = r["title"].lower()
        combined = summary_low + " " + title_low
        if any(kw in combined for kw in contra_keywords):
            contradicciones += 1
            objections.append({
                "severity": "alta",
                "text": f"Paper de arXiv sugiere contradicción: '{r['title'][:80]}' ({r['id']})",
                "source": f"arxiv:{r['id']}"
            })
        if any(kw in combined for kw in apoyo_keywords):
            apoyos += 1

    if contradicciones > 0:
        score = max(0.0, 0.3 - 0.2 * contradicciones)
    elif apoyos > 0:
        score = min(1.0, 0.6 + 0.13 * apoyos)
    else:
        score = 0.5

    return AgentReport(
        agent_id="A4", agent_name="Evidencia real",
        technique="APIs arXiv + OpenAlex (con caché en disco)",
        score=max(0.0, min(1.0, score)),
        objections=objections,
        evidence_cited=evidence,
        notes=f"arxiv={len(arxiv_results)}, openalex={len(openalex_results)}, "
              f"contradictorios={contradicciones}, apoyo={apoyos}"
    )


TERMINOS_HIPOSTASIS = {
    "materia oscura": "Nombre sin mecanismo: etiqueta para masa faltante, no explicación.",
    "energía oscura": "Nombre sin mecanismo: etiqueta para presión negativa, no explicación.",
    "consciencia": "Término que nombra el fenómeno sin proponer sustrato ni mecanismo.",
    "fuerza vital": "Hipóstasis clásica: élan vital de Bergson, refutado por bioquímica.",
    "éter": "Hipóstasis histórica: medio hipotético sin observación independiente.",
    "vulcano": "Hipóstasis histórica: planeta hipotético inventado para explicar anomalía.",
    "flogisto": "Hipóstasis histórica: sustancia hipotética que resultó inexistente.",
    "calórico": "Hipóstasis histórica: fluido hipotético, refutado por termodinámica.",
    "materia": "Posible hipóstasis si se usa como premisa sin definición operacional.",
    "information": "Término polisémico: confundir Shannon con semántica es hipóstasis.",
}


def agente_a5_hipostasis(claim: Claim) -> AgentReport:
    objections: List[Dict[str, str]] = []
    texto_low = claim.raw_input.lower()

    hipostasis_detectadas = []
    for termino, razon in TERMINOS_HIPOSTASIS.items():
        if termino in texto_low:
            hipostasis_detectadas.append((termino, razon))
            for premisa in claim.premisas:
                if termino in premisa.lower():
                    objections.append({
                        "severity": "media",
                        "text": f"Posible hipóstasis: '{termino}' aparece como premisa. {razon}",
                        "source": f"A5-hipostasis:{termino}"
                    })
                    break

    score = 1.0 - 0.2 * len(hipostasis_detectadas)
    score = max(0.0, min(1.0, score))

    return AgentReport(
        agent_id="A5", agent_name="Hipóstasis",
        technique="Heurística explícita (heredado de OSIT v1.0)",
        score=score,
        objections=objections,
        evidence_cited=[f"A5-hipostasis:{t}" for t, _ in hipostasis_detectadas],
        notes=f"terminos_detectados={[t for t, _ in hipostasis_detectadas]}"
    )


def agente_a6_marco(claim: Claim, llm_caller: Optional[Callable] = None) -> AgentReport:
    objections: List[Dict[str, str]] = []
    evidence: List[str] = []

    marcos = claim.marcos_competidores
    if not marcos:
        return AgentReport(
            agent_id="A6", agent_name="Marco competidor",
            technique="LLM + base de marcos (vacía para dominio desconocido)",
            score=0.5,
            objections=[],
            evidence_cited=[],
            notes="Sin marcos competidores conocidos para este dominio."
        )

    if llm_caller is not None:
        prompt = f"""Compara el siguiente claim con los marcos competidores. Para cada marco,
responde: ¿predice el mismo fenómeno? Si no, ¿por qué difiere?

Claim: {claim.raw_input[:300]}

Marcos competidores: {', '.join(marcos)}

Responde en JSON: {{"comparaciones": [{{"marco": "...", "predice_lo_mismo": true/false, "diferencia": "..."}}]}}"""
        try:
            response = llm_caller(prompt)
            data = json.loads(response)
            comparaciones = data.get("comparaciones", [])
            marcos_que_predicen = sum(1 for c in comparaciones if c.get("predice_lo_mismo"))
            for c in comparaciones:
                if not c.get("predice_lo_mismo"):
                    objections.append({
                        "severity": "media",
                        "text": f"Marco competidor '{c.get('marco')}' no predice lo mismo. Diferencia: {c.get('diferencia', '')[:100]}",
                        "source": f"A6-marco:{c.get('marco')}"
                    })
                evidence.append(f"A6:{c.get('marco')}")
            if len(comparaciones) > 0 and marcos_que_predicen == len(comparaciones):
                score = 0.4
                objections.append({
                    "severity": "alta",
                    "text": "El claim coincide con TODOS los marcos competidores: es operacionalmente trivial.",
                    "source": "A6-trivial"
                })
            else:
                score = 0.6 + 0.1 * (len(comparaciones) - marcos_que_predicen)
                score = min(1.0, score)
            technique = "LLM + base de marcos"
        except Exception:
            score = 0.5
            technique = "LLM + base de marcos (fallback)"
    else:
        technique = "Base de marcos estática (sin LLM)"
        for m in marcos[:3]:
            evidence.append(f"A6-marco:{m}")
        score = 0.6

    return AgentReport(
        agent_id="A6", agent_name="Marco competidor",
        technique=technique,
        score=max(0.0, min(1.0, score)),
        objections=objections,
        evidence_cited=evidence,
        notes=f"marcos_evaluados={len(marcos)}"
    )


# ============================================================
#       CAPA 2 — ORQUESTADOR PARALELO (cuello de botella #1)
# ============================================================

# ============================================================
#     AGENTE A1+ — ANÁLISIS DIMENSIONAL (v3.2, spec v7 §4.2)
# ============================================================

# Tabla de dimensiones: símbolos físicos comunes → expresión dimensional.
# L=longitud, T=tiempo, M=masa (representadas como sympy symbols en runtime).
_DIM_TABLE = {
    # unidades base
    "m": "L", "s": "T", "kg": "M", "km": "L", "ms": "T", "hz": "1/T",
    # constantes
    "c": "L/T", "g": "L**3/(M*T**2)", "hbar": "M*L**2/T", "h": "M*L**2/T",
    "k_b": "M*L**2/(T**2*K)",
    # adimensionales
    "alpha": "1", "pi": "1", "beta_1": "1", "beta1": "1", "n": "1",
    "ln": "1", "log": "1", "r2": "1",
    # heurísticas por prefijo (se aplican si el símbolo no está en la tabla):
}
_DIM_PREFIX_HEURISTICS = [
    (("tau", "t_", "dt", "delta_t", "deltat"), "T"),
    (("r_", "l_", "ell", "dist", "radio", "lambda_"), "L"),
    (("m_", "masa", "mass"), "M"),
    (("freq", "f_", "omega", "nu", "rate", "n_dot", "ndot"), "1/T"),
    (("v_", "vel"), "L/T"),
    (("e_", "energ"), "M*L**2/T**2"),
    (("area", "a_h"), "L**2"),
]


def _dim_of_symbol(name: str, symbols_map: dict) -> Optional[Any]:
    """Dimensión de un símbolo por tabla exacta o heurística de prefijo."""
    low = name.lower()
    if low in _DIM_TABLE:
        return symbols_map["parse"](_DIM_TABLE[low])
    for prefixes, dim in _DIM_PREFIX_HEURISTICS:
        if any(low.startswith(p) for p in prefixes):
            return symbols_map["parse"](dim)
    return None  # desconocida → no verificable


def agente_a1plus_dimensional(claim: Claim) -> AgentReport:
    """A1+ — homogeneidad dimensional real vía sympy (no regex).

    Solo emite VIOLACIÓN cuando AMBOS lados de una ecuación resuelven a
    dimensiones conocidas y NO coinciden. Ecuaciones no parseables o con
    símbolos desconocidos = 'no verificable' (severidad baja, penaliza poco).
    Heurística documentada: prefijos tau/t_→tiempo, r_/l_→longitud, etc.
    """
    tech = "sympy (análisis dimensional algebraico + heurística de prefijos)"
    try:
        import sympy
    except ImportError:
        return AgentReport(
            agent_id="A1+", agent_name="Análisis dimensional",
            technique=tech, score=0.6,
            objections=[{"severity": "baja",
                         "text": "sympy no instalado: análisis dimensional no disponible",
                         "source": "A1+-sin-sympy"}],
            evidence_cited=[], notes="sympy ausente")

    L, T, M, K = sympy.symbols("L T M K", positive=True)
    local = {"L": L, "T": T, "M": M, "K": K}
    smap = {"parse": lambda expr: sympy.sympify(expr, locals=local)}

    violaciones: List[Dict[str, str]] = []
    no_verificables = 0
    verificadas = 0

    for eq in claim.ecuaciones[:12]:
        if "=" not in eq or "==" in eq:
            continue
        lhs_s, rhs_s = eq.split("=", 1)
        try:
            # normalizar notación común
            norm = lambda s: re.sub(r"[·×]", "*", s).replace("^", "**").strip()
            lhs_e = sympy.sympify(norm(lhs_s), evaluate=False)
            rhs_e = sympy.sympify(norm(rhs_s), evaluate=False)
            subs = {}
            ok = True
            for sym in (lhs_e.free_symbols | rhs_e.free_symbols):
                d = _dim_of_symbol(str(sym), smap)
                if d is None:
                    ok = False
                    break
                subs[sym] = d
            if not ok:
                no_verificables += 1
                continue
            dim_l = sympy.simplify(lhs_e.subs(subs))
            dim_r = sympy.simplify(rhs_e.subs(subs))
            # números puros colapsan a adimensional
            if dim_l.is_number:
                dim_l = sympy.Integer(1)
            if dim_r.is_number:
                dim_r = sympy.Integer(1)
            verificadas += 1
            if sympy.simplify(dim_l / dim_r) != 1:
                violaciones.append({
                    "severity": "alta",
                    "text": f"Violación dimensional en '{eq[:70]}': "
                            f"[{dim_l}] ≠ [{dim_r}]",
                    "source": "A1+-dimensional",
                })
        except Exception:
            no_verificables += 1
            continue

    objections = list(violaciones)
    if no_verificables and not violaciones and not verificadas:
        objections.append({
            "severity": "baja",
            "text": f"{no_verificables} ecuaciones no verificables dimensionalmente "
                    f"(símbolos fuera de tabla o sin parsear) — no penaliza fuerte",
            "source": "A1+-no-verificable",
        })

    score = max(0.0, 1.0 - 0.30 * len(violaciones) - 0.05 * min(no_verificables, 3))
    return AgentReport(
        agent_id="A1+", agent_name="Análisis dimensional",
        technique=tech, score=round(score, 3),
        objections=objections, evidence_cited=[],
        notes=f"verificadas={verificadas}, violaciones={len(violaciones)}, "
              f"no_verificables={no_verificables}",
        abstained=(verificadas == 0 and not violaciones))


# ============================================================
#   AGENTE A7 — CONSISTENCIA NUMÉRICA INTERNA (v3.2, spec v7 §4.8)
# ============================================================

def agente_a7_consistencia(claim: Claim) -> AgentReport:
    """A7 — recomputa ratios/afirmaciones numéricas DEL PROPIO texto.

    Patrones (de la spec v7 + auditoría TCR):
      1. 'X× la cota' con X>1 junto a lenguaje de 'se aproxima/debajo' → posible inversión.
      2. '1.000000' + 'universal' → posible identidad por construcción.
      3. conteo entero (beta_1, N) igualado a valor < 1 (p.ej. 10^-54).
      4. 'A/B = C' donde el recomputo difiere >5% del C impreso.
    """
    text = claim.raw_input.lower()
    objections: List[Dict[str, str]] = []

    # 1. ratio vs narrativa
    for m in re.finditer(r"(\d+(?:[.,]\d+)?)\s*[x×]\s*(?:la\s+cota|the\s+bound)", text):
        val = float(m.group(1).replace(",", "."))
        if val > 1.0 and re.search(r"approach|aproxim|debajo|below|cumple|satisface", text):
            objections.append({
                "severity": "alta",
                "text": f"Ratio '{m.group(1)}× la cota' (>1 = VIOLACIÓN) pero el texto "
                        f"narra aproximación/cumplimiento — posible división invertida",
                "source": "A7-ratio-invertido"})

    # 2. identidad por construcción
    if re.search(r"1[.,]0{4,}", text) and re.search(r"universal|exact", text):
        objections.append({
            "severity": "alta",
            "text": "'1.000000…' presentado como universal/exacto: verificar que no sea "
                    "identidad por construcción (A·(1/A) ≡ 1 no verifica física)",
            "source": "A7-identidad"})

    # 3. conteos enteros < 1
    for m in re.finditer(r"(beta[_\s]?1|β1|n)\s*[=≈~]\s*10\^?[\{\(]?-(\d+)", text):
        objections.append({
            "severity": "alta",
            "text": f"Conteo entero '{m.group(1)}' igualado a 10^-{m.group(2)} — un conteo "
                    f"no puede ser < 1 (posible división invertida)",
            "source": "A7-conteo-menor-1"})

    # 4. recomputo de 'A/B = C'
    for m in re.finditer(
            r"(\d+(?:[.,]\d+)?(?:e-?\d+)?)\s*/\s*(\d+(?:[.,]\d+)?(?:e-?\d+)?)\s*[=≈]\s*"
            r"(-?\d+(?:[.,]\d+)?(?:e-?\d+)?)", text):
        try:
            a = float(m.group(1).replace(",", "."))
            b = float(m.group(2).replace(",", "."))
            c = float(m.group(3).replace(",", "."))
            if b != 0 and c != 0:
                real = a / b
                if abs(real - c) / abs(c) > 0.05:
                    objections.append({
                        "severity": "media",
                        "text": f"Recomputo: {m.group(1)}/{m.group(2)} = {real:.4g}, "
                                f"pero el texto imprime {m.group(3)} (>5% de desviación)",
                        "source": "A7-recomputo"})
        except (ValueError, ZeroDivisionError):
            continue

    score = max(0.0, 1.0 - 0.20 * len(objections))
    return AgentReport(
        agent_id="A7", agent_name="Consistencia numérica interna",
        technique="Recomputo de ratios y detección de contradicciones internas (regex+aritmética)",
        score=round(score, 3),
        objections=objections, evidence_cited=[],
        notes=f"patrones_disparados={len(objections)}",
        abstained=(len(objections) == 0))  # silencio de patrones ≠ consistencia probada


def ejecutar_agentes_paralelo(claim: Claim,
                              llm_caller: Optional[Callable] = None,
                              max_workers: int = 6) -> List[AgentReport]:
    """Ejecuta los 6 agentes en paralelo con ThreadPoolExecutor.

    cuello de botella #1 atacado:
      v2.0 secuencial: ~30-90s (suma de los 6 agentes, A4 domina)
      v3.0 paralelo:   ~10-30s (máximo de los 6, no suma)
    """
    def run_a1(): return agente_a1_logica(claim)
    def run_a1p(): return agente_a1plus_dimensional(claim)
    def run_a2(): return agente_a2_parsimonia(claim)
    def run_a3(): return agente_a3_falsabilidad(claim, llm_caller=llm_caller)
    def run_a4(): return agente_a4_evidencia(claim)
    def run_a5(): return agente_a5_hipostasis(claim)
    def run_a6(): return agente_a6_marco(claim, llm_caller=llm_caller)
    def run_a7(): return agente_a7_consistencia(claim)

    agents = [
        ("A1", run_a1),
        ("A1+", run_a1p),
        ("A2", run_a2),
        ("A3", run_a3),
        ("A4", run_a4),
        ("A5", run_a5),
        ("A6", run_a6),
        ("A7", run_a7),
    ]
    orden = [a_id for a_id, _ in agents]

    results: Dict[str, AgentReport] = {}
    with ThreadPoolExecutor(max_workers=max(max_workers, 8)) as executor:
        futures = {executor.submit(fn): agent_id for agent_id, fn in agents}
        for future in as_completed(futures):
            agent_id = futures[future]
            try:
                results[agent_id] = future.result(timeout=120)
            except Exception as e:
                # Si un agente falla, no se cae todo el sistema
                results[agent_id] = AgentReport(
                    agent_id=agent_id,
                    agent_name=f"Agente {agent_id} (fallido)",
                    technique="error",
                    score=0.3,
                    objections=[{
                        "severity": "media",
                        "text": f"Agente falló durante la ejecución: {str(e)[:100]}",
                        "source": f"{agent_id}-error"
                    }],
                    evidence_cited=[],
                    notes=f"exception: {type(e).__name__}"
                )

    # Devolver en orden A1, A1+, A2..A7
    return [results[a_id] for a_id in orden]


# ============================================================
#                CAPA 3 — INTEGRADOR
# ============================================================

# v3.2 — pesos de los 8 agentes (spec v7 tabla 1); deben sumar 1.0
PESOS_AGENTES = {
    "A1": 0.22, "A1+": 0.03, "A2": 0.10, "A3": 0.18,
    "A4": 0.22, "A5": 0.08, "A6": 0.08, "A7": 0.09,
}
assert abs(sum(PESOS_AGENTES.values()) - 1.0) < 1e-9, \
    f"PESOS_AGENTES no suman 1.0: {sum(PESOS_AGENTES.values())}"

# Integrador por default. 'geometrico' = agresivo a propósito (un cero no-fatal
# arrastra); 'ponderado' = spec v7 §5 (media ponderada + penalización varianza,
# solo colapsa con is_fatal). Se elige con --integrador o DECES_INTEGRADOR.
INTEGRADOR_DEFAULT = os.environ.get("DECES_INTEGRADOR", "geometrico")


def integrar(reports: List[AgentReport], claim: Claim,
             modelo: str = "default-local",
             similar_to: Optional[str] = None,
             metodo: Optional[str] = None) -> Veredicto:
    metodo = (metodo or INTEGRADOR_DEFAULT).lower()

    # v3.2 — refutación CONCLUYENTE colapsa SIEMPRE, en ambos métodos
    fatal = any(getattr(rep, "is_fatal", False) for rep in reports)

    # v3.2 — los agentes ABSTENIDOS no participan (evita dilución de exponentes);
    # los pesos activos se renormalizan a suma 1
    activos = [rep for rep in reports if not getattr(rep, "abstained", False)]
    if not activos:
        activos = reports
    w_total = sum(PESOS_AGENTES.get(rep.agent_id, 0.1) for rep in activos)

    if fatal:
        r = 0.0
    elif metodo == "ponderado":
        # spec v7 §5: media ponderada + penalización por varianza (alpha=0.5)
        mean = sum(rep.score * PESOS_AGENTES.get(rep.agent_id, 0.1)
                   for rep in activos) / w_total if w_total > 0 else 0.0
        var = sum(PESOS_AGENTES.get(rep.agent_id, 0.1) * (rep.score - mean) ** 2
                  for rep in activos) / w_total if w_total > 0 else 0.0
        r = mean - 0.5 * var
    else:  # geometrico (default)
        r = 1.0
        for rep in activos:
            w = PESOS_AGENTES.get(rep.agent_id, 0.1) / w_total
            if rep.score > 0:
                r *= rep.score ** w
            else:
                r = 0.0
                break
    r = max(0.0, min(1.0, r))

    nivel = EpistemicLevel.from_r(r)

    todas_objeciones = []
    for rep in reports:
        for obj in rep.objections:
            todas_objeciones.append({**obj, "agente": rep.agent_id})
    severity_order = {"alta": 0, "media": 1, "baja": 2}
    todas_objeciones.sort(key=lambda o: severity_order.get(o["severity"], 3))
    objeciones_fuertes = todas_objeciones[:3]

    experimento = "No se pudo derivar experimento discriminante (insuficientes predicciones)."
    for rep in reports:
        if rep.agent_id == "A3" and rep.notes:
            experimento = f"Realizar observación que distinga las predicciones: {rep.notes}. " \
                         f"Si el resultado contradice las predicciones cuantitativas, la teoría es refutada."
            break
        if rep.agent_id == "A4" and rep.evidence_cited:
            experimento = f"Replicar o contrastar con los papers citados: {', '.join(rep.evidence_cited[:2])}. " \
                         f"Diseñar observación que distinga el claim de las predicciones del marco estándar."
            break

    fuentes = []
    for rep in reports:
        fuentes.extend(rep.evidence_cited)
    fuentes = list(dict.fromkeys(fuentes))[:5]
    while len(fuentes) < 5:
        fuentes.append(f"(sin fuente adicional)")

    return Veredicto(
        claim_id=claim.claim_id(),
        claim=claim.raw_input[:200],
        dominio=claim.dominio,
        nivel=int(nivel),
        nivel_label=nivel.label(),
        r_score=round(r, 4),
        objeciones_fuertes=objeciones_fuertes,
        experimento_discriminante=experimento,
        fuentes=fuentes,
        timestamp=datetime.now(timezone.utc).isoformat(),
        modelo=modelo,
        agentes=[rep.to_dict() for rep in reports],
        similar_to=similar_to,
        integrador=metodo if not fatal else f"{metodo}+fatal",
    )


# ============================================================
#                CAPA 4 — TRAZA
# ============================================================

def guardar_traza_archivo(veredicto: Veredicto, claim: Claim) -> str:
    """Guarda veredicto.json + veredicto.txt en disco."""
    base = os.path.join(str(TRACES_DIR), veredicto.claim_id.replace("...", "_"))
    with open(f"{base}.json", "w", encoding="utf-8") as f:
        json.dump(veredicto.to_dict(), f, indent=2, ensure_ascii=False)
    txt = render_veredicto_texto(veredicto)
    with open(f"{base}.txt", "w", encoding="utf-8") as f:
        f.write(txt)
    return base


_NIVEL_CLARO = {
    0: ("CONTRADICHA", "La afirmación choca con evidencia concluyente o se "
        "contradice a sí misma. No la uses como base de nada."),
    1: ("MUY IMPROBABLE", "Casi todo apunta en contra. Solo tendría rescate con "
        "evidencia nueva y extraordinaria."),
    2: ("ESPECULATIVA", "Es coherente pero no hay evidencia que la respalde. "
        "Trátala como idea interesante, no como conocimiento."),
    3: ("COMPATIBLE", "Es una hipótesis formal seria: tiene forma de ser puesta "
        "a prueba y algo de apoyo. Aún NO está demostrada."),
    4: ("PROMETEDORA", "Varias líneas de evidencia independientes la apoyan. "
        "Sigue siendo provisional — la ciencia no da sellos eternos."),
    5: ("FUERTEMENTE RESPALDADA", "Ha sobrevivido muchos intentos serios de "
        "refutarla. Es lo más cerca de 'confiable' que otorga este tribunal."),
}


def _render_modo_claro(v: Veredicto) -> str:
    """Explicación en lenguaje llano (es-MX, literal, sin jerga)."""
    titulo, explic = _NIVEL_CLARO.get(v.nivel, ("?", ""))
    out = []
    out.append("─" * 65)
    out.append("EN PALABRAS SIMPLES (modo claro)")
    out.append(f"  Resultado: nivel {v.nivel} de 5 — {titulo}.")
    out.append(f"  Qué significa: {explic}")
    if v.objeciones_fuertes:
        out.append("  El problema más serio que encontró el tribunal:")
        peor = v.objeciones_fuertes[0]
        out.append(f"    → {peor.get('text', '')[:180]}")
    out.append("  Qué hacer con esto:")
    if v.nivel <= 1:
        out.append("    No difundas la afirmación como cierta. Si es tuya, revisa la")
        out.append("    objeción de arriba antes de invertir más tiempo.")
    elif v.nivel == 2:
        out.append("    Puedes explorarla, pero preséntala siempre como especulación.")
    elif v.nivel == 3:
        out.append("    Puedes citarla como hipótesis con falsadores. El experimento")
        out.append("    discriminante de arriba dice exactamente cómo probarla.")
    else:
        out.append("    Puedes usarla con confianza razonable, citando las fuentes.")
    out.append("  Este veredicto es de un programa, no de un humano experto: es un")
    out.append("  filtro de calidad reproducible (el sello de abajo lo garantiza),")
    out.append("  no la verdad final.")
    return "\n".join(out)


def render_veredicto_texto(v: Veredicto, claro: bool = False) -> str:
    line = "═" * 65
    out = []
    out.append("VEREDICTO DECES")
    out.append(line)
    out.append(f"CLAIM ID       : {v.claim_id}")
    out.append(f"INPUT          : {v.claim}")
    out.append(f"DOMINIO        : {v.dominio}")
    out.append(f"TIMESTAMP      : {v.timestamp}")
    out.append(f"MODELO         : {v.modelo}")
    if v.cached:
        out.append(f"CACHÉ          : reutilizado de auditoría previa")
        if v.similar_to:
            out.append(f"SIMILAR A      : {v.similar_to}")
    out.append(line)
    out.append(f"NIVEL          : {v.nivel}  {v.nivel_label}   [R = {v.r_score}]")
    out.append(line)
    out.append("OBJECIONES FUERTES:")
    for i, obj in enumerate(v.objeciones_fuertes, 1):
        out.append(f"  [{obj.get('agente', '?')}] {obj.get('text', '')}")
        out.append(f"        (severidad: {obj.get('severity', '?')}, "
                   f"fuente: {obj.get('source', '?')})")
    out.append(line)
    out.append("EXPERIMENTO DISCRIMINANTE:")
    out.append(f"  {v.experimento_discriminante}")
    out.append(line)
    out.append("FUENTES:")
    for i, src in enumerate(v.fuentes, 1):
        out.append(f"  [{i}] {src}")
    out.append(line)
    out.append(f"TRAZA          : {TRACES_DIR}/{v.claim_id.replace('...', '_')}.json")
    out.append(f"DB             : {DB_PATH}")
    out.append(f"REAUDITABLE    : {'sí' if v.reauditable else 'no'} · "
               f"nueva evidencia dispara reevaluación")
    sello = hashlib.sha256(
        json.dumps(v.to_dict(), sort_keys=True, ensure_ascii=False).encode("utf-8")
    ).hexdigest()[:16]
    out.append(line)
    out.append(f"SELLO DECES    : nivel={v.nivel} R={v.r_score} claim={v.claim_id} "
               f"hash={sello}")
    out.append(f"INTEGRADOR     : {getattr(v, 'integrador', 'geometrico')}")
    out.append("REGLA DEL SELLO: ningún documento porta «DECES · Nivel X» sin este")
    out.append("                 sello y su traza JSON adjunta. Sello de una versión")
    out.append("                 anterior del documento = veredicto NO vigente.")
    if claro:
        out.append(_render_modo_claro(v))
    return "\n".join(out) + "\n"


# ============================================================
#                   ORQUESTADOR v3.0
# ============================================================

def audit(texto: str, llm_caller: Optional[Callable] = None,
          modelo: str = "default-local",
          use_cache: bool = True,
          similarity_threshold: float = 0.85,
          integrador: Optional[str] = None) -> Veredicto:
    """Pipeline completo con memoria: ingest → memoria check → 6 agentes paralelos → integrar → traza.

    cuello de botella #3 atacado (memoria):
      v2.0: cada auditoría empieza desde cero, no sabe si ya evaluó esto
      v3.0: si el claim o uno similar (Jaccard >= 0.85) está en DB, reutiliza
    """
    # Capa 1
    claim = ingest(texto)

    # Abrir DB
    conn = get_db()

    # Capa 0.5 — buscar en memoria
    if use_cache:
        # 1. Búsqueda exacta
        prev_veredicto_dict = buscar_claim_exacto(conn, claim)
        if prev_veredicto_dict:
            v = veredicto_from_dict(prev_veredicto_dict, claim)
            v.modelo = f"{modelo} (cached)"
            # Guardar traza aunque sea cacheada
            guardar_traza_archivo(v, claim)
            conn.close()
            return v

        # 2. Búsqueda por similitud (solo si threshold alto para no falsear)
        if similarity_threshold > 0:
            similares = buscar_claims_similares(conn, claim,
                                                threshold=similarity_threshold,
                                                limit=1)
            if similares:
                similar_id = similares[0]["claim_id"]
                similar_v_dict = cargar_veredicto_db(conn, similar_id)
                if similar_v_dict:
                    v = veredicto_from_dict(similar_v_dict, claim)
                    v.modelo = f"{modelo} (cached from {similar_id})"
                    v.similar_to = similar_id
                    # Guardar el claim nuevo en DB
                    guardar_claim_db(conn, claim)
                    guardar_veredicto_db(conn, v)
                    guardar_traza_archivo(v, claim)
                    conn.close()
                    return v

    # Capa 2 — 8 agentes EN PARALELO (v3.2: A1, A1+, A2..A7)
    reports = ejecutar_agentes_paralelo(claim, llm_caller=llm_caller)

    # Capa 3
    veredicto = integrar(reports, claim, modelo=modelo, metodo=integrador)

    # Capa 4 — traza en archivo + DB
    guardar_claim_db(conn, claim)
    guardar_veredicto_db(conn, veredicto)
    guardar_traza_archivo(veredicto, claim)

    conn.close()
    return veredicto


def make_llm_caller() -> Optional[Callable]:
    """Crea un LLM caller si hay Ollama local o DECES_API_KEY configurada."""
    try:
        def ollama_call(prompt: str) -> str:
            data = json.dumps({
                "model": os.environ.get("DECES_OLLAMA_MODEL", "qwen2.5:7b"),
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.3, "num_predict": 800}
            }).encode()
            req = urllib.request.Request(
                "http://localhost:11434/api/generate",
                data=data,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode())
                return result.get("response", "")
        test = cached_http_get("http://localhost:11434/api/tags", timeout=2.0, ttl=60)
        if test is not None:
            print(f"[deces] Ollama local detectado, usando modelo "
                  f"{os.environ.get('DECES_OLLAMA_MODEL', 'qwen2.5:7b')}", file=sys.stderr)
            return ollama_call
    except Exception:
        pass

    api_key = os.environ.get("DECES_API_KEY")
    if api_key:
        provider = os.environ.get("DECES_API_PROVIDER", "nim")
        print(f"[deces] API externa detectada: {provider}", file=sys.stderr)
        return None

    print("[deces] Sin LLM disponible — A3 y A6 usarán plantillas determinísticas",
          file=sys.stderr)
    return None


# ============================================================
#                     CLI
# ============================================================

def cmd_audit(args):
    if args.input:
        with open(args.input, "r", encoding="utf-8") as f:
            texto = f.read()
    elif args.arxiv:
        url = f"http://export.arxiv.org/abs/{args.arxiv}"
        html = cached_http_get(url, timeout=15.0)
        if not html:
            print(f"Error: no se pudo descargar arXiv:{args.arxiv}", file=sys.stderr)
            sys.exit(1)
        m = re.search(r'<blockquote class="abstract[^"]*">(.*?)</blockquote>',
                      html, re.DOTALL)
        if m:
            texto = re.sub(r'<[^>]+>', '', m.group(1)).strip()
        else:
            print(f"Error: no se pudo extraer abstract de arXiv:{args.arxiv}",
                  file=sys.stderr)
            sys.exit(1)
    elif args.claim:
        texto = args.claim
    else:
        print("Error: debe proporcionar --claim, --input o --arxiv", file=sys.stderr)
        sys.exit(1)

    llm = make_llm_caller() if not args.no_llm else None

    t0 = time.time()
    veredicto = audit(texto, llm_caller=llm, modelo=args.modelo,
                     use_cache=not args.no_cache,
                     similarity_threshold=0.0 if args.no_cache else 0.85,
                     integrador=getattr(args, "integrador", None))
    elapsed = time.time() - t0

    if args.json:
        d = veredicto.to_dict()
        d["_elapsed_seconds"] = round(elapsed, 2)
        print(json.dumps(d, indent=2, ensure_ascii=False))
    else:
        print(render_veredicto_texto(veredicto, claro=getattr(args, "claro", False)))
        print(f"\n[deces] Audit completada en {elapsed:.1f}s")


def cmd_test(args):
    from test_deces import HISTORICAL_CASES, run_test_suite
    results = run_test_suite(make_llm_caller() if not args.no_llm else None)
    print("\n" + "=" * 60)
    print(f"TEST SUMMARY: {sum(1 for r in results if r['pass'])}/{len(results)} casos correctos")
    for r in results:
        status = "✓" if r["pass"] else "✗"
        print(f"  {status} {r['claim_id']} | esperado={r['esperado']} | actual={r['actual']} | {r['nombre'][:50]}")


def cmd_history(args):
    conn = get_db()
    v_dict = cargar_veredicto_db(conn, args.claim_id)
    conn.close()
    if not v_dict:
        print(f"Error: no se encontró veredicto para {args.claim_id}", file=sys.stderr)
        sys.exit(1)
    claim_row = None
    with sqlite3.connect(str(DB_PATH)) as c2:
        c2.row_factory = sqlite3.Row
        claim_row = c2.execute(
            "SELECT raw_input, dominio FROM claims WHERE claim_id = ?",
            (args.claim_id,)
        ).fetchone()
    if claim_row:
        claim = Claim(
            raw_input=claim_row["raw_input"],
            dominio=claim_row["dominio"],
            premisas=[], predicciones=[], supuestos_implicitos=[],
            marcos_competidores=[]
        )
        v = veredicto_from_dict(v_dict, claim)
        print(render_veredicto_texto(v))


def cmd_stats(args):
    """deces stats — estadísticas de la DB."""
    conn = get_db()
    n_claims = conn.execute("SELECT COUNT(*) FROM claims").fetchone()[0]
    n_verdicts = conn.execute("SELECT COUNT(*) FROM verdicts").fetchone()[0]
    n_cached = conn.execute("SELECT COUNT(*) FROM verdicts WHERE cached = 1").fetchone()[0]
    n_agents = conn.execute("SELECT COUNT(*) FROM agent_reports").fetchone()[0]
    n_cache = conn.execute("SELECT COUNT(*) FROM http_cache").fetchone()[0]
    cache_size_mb = sum(f.stat().st_size for f in CACHE_DIR.iterdir() if f.is_file()) / 1024 / 1024

    print("DECES — Estadísticas de memoria")
    print("═" * 50)
    print(f"DB path          : {DB_PATH}")
    print(f"Claims auditados : {n_claims}")
    print(f"Veredictos       : {n_verdicts}")
    print(f"  cached         : {n_cached}")
    print(f"Agent reports    : {n_agents}")
    print(f"HTTP cache files : {n_cache} ({cache_size_mb:.1f} MB)")
    print()
    print("Distribución por nivel:")
    for nivel in range(6):
        n = conn.execute(
            "SELECT COUNT(*) FROM verdicts WHERE nivel = ?", (nivel,)
        ).fetchone()[0]
        label = EpistemicLevel(nivel).label()
        bar = "█" * min(n, 30)
        print(f"  {nivel} {label:30s} {n:4d} {bar}")
    print()
    print("Distribución por dominio:")
    rows = conn.execute(
        "SELECT dominio, COUNT(*) as n FROM claims GROUP BY dominio ORDER BY n DESC"
    ).fetchall()
    for r in rows:
        print(f"  {r['dominio']:20s} {r['n']:4d}")
    conn.close()


def cmd_similar(args):
    """deces similar "claim" — busca claims similares en memoria."""
    texto = args.claim
    claim = ingest(texto)
    conn = get_db()
    similares = buscar_claims_similares(conn, claim, threshold=0.3, limit=10)
    if not similares:
        print("No se encontraron claims similares en memoria.")
        conn.close()
        return
    print(f"Claims similares a:\n  {texto[:80]}...\n")
    for s in similares:
        v_dict = cargar_veredicto_db(conn, s["claim_id"])
        if v_dict:
            nivel = v_dict["nivel"]
            label = v_dict["nivel_label"]
            print(f"  [{s['similarity']:.2f}] {s['claim_id']} nivel={nivel} ({label})")
            print(f"         {s['raw_input'][:80]}...")
    conn.close()


def cmd_clear_cache(args):
    """deces clear-cache — limpia caché HTTP y/o DB."""
    if args.http_only:
        for f in CACHE_DIR.iterdir():
            if f.is_file():
                f.unlink()
        print(f"Caché HTTP limpiado: {CACHE_DIR}")
    elif args.db_only:
        if DB_PATH.exists():
            DB_PATH.unlink()
        print(f"DB eliminada: {DB_PATH}")
    else:
        for f in CACHE_DIR.iterdir():
            if f.is_file():
                f.unlink()
        if DB_PATH.exists():
            DB_PATH.unlink()
        print(f"Caché HTTP + DB limpiados")


def cmd_genesis(args):
    """deces genesis <subcomando> — despacha a genesis.py (GENESIS, Capa -1
    de generación). Import perezoso a propósito: genesis.py importa de este
    archivo, así que importarlo a nivel de módulo aquí crearía un ciclo.
    GENESIS es una capa OPCIONAL — si genesis.py no está presente junto a
    deces.py, el resto de la herramienta (audit/test/history/stats/similar)
    sigue funcionando exactamente igual; DECES no depende de GENESIS."""
    try:
        import genesis
    except ImportError as e:
        print("Error: no se encontró genesis.py (módulo de generación, opcional).", file=sys.stderr)
        print("Colócalo en el mismo directorio que deces.py para habilitar 'deces genesis'.", file=sys.stderr)
        print(f"({e})", file=sys.stderr)
        sys.exit(1)

    # v3.2: mapeo defensivo — la copia de genesis.py disponible puede ser una
    # iteración sin algún comando (skew detectado 2026-07-10: faltaba
    # cmd_pendulo_demo). Solo se ofrecen los que existen de verdad.
    posibles = {
        "test": "cmd_test",
        "minar": "cmd_minar",
        "fisico-demo": "cmd_fisico_demo",
        "pendulo-demo": "cmd_pendulo_demo",
        "fisico": "cmd_fisico_csv",
    }
    despacho = {k: getattr(genesis, v) for k, v in posibles.items()
                if hasattr(genesis, v)}
    if args.genesis_cmd not in despacho:
        print(f"Error: el comando '{args.genesis_cmd}' no existe en esta copia de "
              f"genesis.py. Disponibles: {', '.join(sorted(despacho))}", file=sys.stderr)
        sys.exit(1)
    despacho[args.genesis_cmd](args)


def main():
    p = argparse.ArgumentParser(
        prog="deces",
        description="DECES v3.0 — Dubito Ergo Cogito Ergo Sum. Tribunal epistémico adversarial.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    p_audit = sub.add_parser("audit", help="Auditar un claim")
    p_audit.add_argument("claim", nargs="?")
    p_audit.add_argument("--input")
    p_audit.add_argument("--arxiv")
    p_audit.add_argument("--json", action="store_true")
    p_audit.add_argument("--no-llm", action="store_true")
    p_audit.add_argument("--no-cache", action="store_true",
                        help="No usar memoria (re-ejecuta todo desde cero)")
    p_audit.add_argument("--modelo", default="default-local")
    p_audit.add_argument("--integrador", choices=["geometrico", "ponderado"],
                        default=None,
                        help="Método del integrador (default: geometrico, o "
                             "DECES_INTEGRADOR). 'ponderado' = spec v7 §5")
    p_audit.add_argument("--claro", action="store_true",
                        help="Añade explicación en lenguaje llano (es-MX, sin "
                             "jerga) — para universidades y uso accesible")
    p_audit.set_defaults(func=cmd_audit)

    p_test = sub.add_parser("test", help="Ejecutar test histórico")
    p_test.add_argument("--no-llm", action="store_true")
    p_test.set_defaults(func=cmd_test)

    p_hist = sub.add_parser("history", help="Re-mostrar veredicto previo")
    p_hist.add_argument("--claim-id", required=True)
    p_hist.set_defaults(func=cmd_history)

    p_stats = sub.add_parser("stats", help="Estadísticas de memoria")
    p_stats.set_defaults(func=cmd_stats)

    p_sim = sub.add_parser("similar", help="Buscar claims similares en memoria")
    p_sim.add_argument("claim")
    p_sim.set_defaults(func=cmd_similar)

    p_clear = sub.add_parser("clear-cache", help="Limpiar caché HTTP/DB")
    p_clear.add_argument("--http-only", action="store_true")
    p_clear.add_argument("--db-only", action="store_true")
    p_clear.set_defaults(func=cmd_clear_cache)

    p_genesis = sub.add_parser(
        "genesis",
        help="Capa -1 de generación (GENESIS, módulo opcional — ver genesis.py)")
    genesis_sub = p_genesis.add_subparsers(dest="genesis_cmd", required=True)

    g_test = genesis_sub.add_parser("test", help="Auto-test: ¿el motor redescubre identidades ya conocidas?")

    g_minar = genesis_sub.add_parser("minar", help="Buscar relaciones aritméticas exactas (GENESIS-MATEMÁTICO)")
    g_minar.add_argument("--clase", default="semiprimos",
                          help="semiprimos | primos | cuadrados_primos")
    g_minar.add_argument("--funciones", default="n,nprime,phi,sigma,tau,uno")
    g_minar.add_argument("--n-ajuste", type=int, default=12)
    g_minar.add_argument("--n-validacion", type=int, default=300)
    g_minar.add_argument("--seed", type=int, default=42)
    g_minar.add_argument("--auditar", action="store_true",
                          help="Pasar cada candidato por el panel DECES completo (A1-A6)")
    g_minar.add_argument("--no-cache", action="store_true")

    g_fis_demo = genesis_sub.add_parser(
        "fisico-demo", help="Demo de regresión de ley de potencia (GENESIS-FÍSICO, datos sintéticos)")
    g_fis_demo.add_argument("--auditar", action="store_true")
    g_fis_demo.add_argument("--no-cache", action="store_true")

    g_pend = genesis_sub.add_parser(
        "pendulo-demo", help="Demo de restricción dimensional (péndulo + variable espuria, Buckingham Pi)")
    g_pend.add_argument("--auditar", action="store_true")
    g_pend.add_argument("--no-cache", action="store_true")

    g_fis = genesis_sub.add_parser(
        "fisico", help="Regresión de ley de potencia sobre datos REALES (GENESIS-FÍSICO, CSV)")
    g_fis.add_argument("--csv", required=True, help="Ruta al archivo CSV con los datos")
    g_fis.add_argument("--variables", required=True, help="Columnas de entrada, separadas por coma")
    g_fis.add_argument("--objetivo", required=True, help="Columna de salida a explicar")
    g_fis.add_argument("--contexto", default="dataset provisto por el usuario")
    g_fis.add_argument("--unidades", default=None,
                        help="Unidades por variable, 'var:unidad,var:unidad' (ej: 'masa:kg,radio:m')")
    g_fis.add_argument("--unidad-objetivo", default=None, dest="unidad_objetivo",
                        help="Unidad de la columna objetivo; requiere --unidades")
    g_fis.add_argument("--auditar", action="store_true")
    g_fis.add_argument("--no-cache", action="store_true")

    p_genesis.set_defaults(func=cmd_genesis)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
