#!/usr/bin/env python3
"""
genesis.py — GENESIS: Capa -1 (generación) para DECES v3.x
============================================================
DECES juzga. GENESIS propone. GENESIS nunca se salta al juez.

DECES v3.0 declara explícitamente en su spec (§9, no-goals):
    "No genera teorías desde la nada. DECES no es AI Scientist. No propone
    hipótesis nuevas. [...] Si se implementa en el futuro, sería un módulo
    separado, no parte del núcleo."
y en §11.7:
    "v3.0 no es GENESIS, no es SDOS, no es grafo de teorías."

Este módulo es ese "GENESIS" — implementado como capa separada que NO
modifica una sola línea de deces.py. Importa su núcleo (Claim, los 6
agentes, el integrador, la memoria, la traza) y lo reutiliza sin tocarlo.

PRINCIPIO DE DISEÑO — por qué esto no es "un LLM inventando teorías":
    GENESIS nunca genera texto libre y le pide a un LLM que "invente física".
    Ese camino es exactamente el modo de fallo que DECES fue diseñado para
    evitar (alucinación, fabricación de URLs — el fallo canónico de MOI v1.0
    documentado en el spec). En cambio, GENESIS busca de forma combinatoria/
    estructurada dentro de un espacio de hipótesis matemáticamente bien
    definido, y cada candidato se verifica MECÁNICAMENTE (álgebra exacta o
    ajuste numérico con métrica de error) ANTES de convertirse en Claim.
    Sólo entonces entra, sin privilegios, al mismo tribunal adversarial que
    audita los claims de un humano. DUBITO se aplica con IGUAL o MAYOR
    severidad a lo que GENESIS produce: nada generado por máquina se muestra
    sin pasar por los 6 ángulos de ataque.

    generar → pre-filtrar mecánicamente → Claim → auditar (A1-A6, sin cambios)
                                                        → sólo sobreviven
                                                          los que aguantan

DOS GENERADORES EN ESTE PROTOTIPO:
    GENESIS-MATEMÁTICO — minería de relaciones lineales EXACTAS entre
        funciones aritméticas (n, derivada aritmética, φ, σ, τ) sobre
        clases de enteros (semiprimos), vía espacio nulo de álgebra lineal
        exacta con Fraction (sin dependencias). Validación fuera de muestra
        + verificación simbólica independiente (sympy, opcional) que
        promueve una conjetura numérica a demostración algebraica.
        Ancla en resultados ya establecidos por el autor (MOPN): para
        semiprimos N=p·q, N'(N) = p+q.

    GENESIS-FÍSICO — regresión de leyes de potencia en log-log
        (y = C·∏xᵢ^aᵢ), con "redondeo tipo Ockham" de exponentes a
        fracciones simples y medición explícita de la pérdida de ajuste.
        Prototipo sobre datos SINTÉTICOS (ver limitaciones en el cierre);
        el mismo mecanismo se conecta a datasets reales (Planck, DESI-BAO,
        GWOSC) cambiando sólo la función que carga `datos`.

USO
    python3 genesis.py test                    # auto-test: ¿redescubre identidades YA CONOCIDAS?
    python3 genesis.py minar --auditar          # minería matemática + auditoría DECES completa
    python3 genesis.py fisico-demo --auditar    # demo de regresión de potencias + auditoría DECES

Autor: extensión de GENESIS sobre DECES v3.0 de Luis René González López (Tyr/Lutren)
Licencia: MIT (misma que deces.py)
"""
from __future__ import annotations

import argparse
import csv
import math
import random
import sys
from dataclasses import dataclass
from fractions import Fraction
from functools import reduce
from math import gcd
from typing import Any, Callable, Dict, List, Optional, Tuple

from deces import (
    Claim,
    Veredicto,
    get_db,
    buscar_claim_exacto,
    veredicto_from_dict,
    buscar_claims_similares,
    cargar_veredicto_db,
    guardar_traza_archivo,
    guardar_claim_db,
    guardar_veredicto_db,
    ejecutar_agentes_paralelo,
    integrar,
    marcos_por_dominio,
    render_veredicto_texto,
)

# ============================================================
# PARTE I — FUNCIONES ARITMÉTICAS DE BASE (para GENESIS-MATEMÁTICO)
# ============================================================

def factorizar(n: int) -> Dict[int, int]:
    """Factorización prima por división de prueba."""
    factores: Dict[int, int] = {}
    temp = n
    d = 2
    while d * d <= temp:
        while temp % d == 0:
            factores[d] = factores.get(d, 0) + 1
            temp //= d
        d += 1 if d == 2 else 2
    if temp > 1:
        factores[temp] = factores.get(temp, 0) + 1
    return factores


def es_primo(n: int) -> bool:
    if n < 2:
        return False
    if n < 4:
        return True
    if n % 2 == 0:
        return False
    d = 3
    while d * d <= n:
        if n % d == 0:
            return False
        d += 2
    return True


def derivada_aritmetica(n: int) -> int:
    """n' = n * Σ(aᵢ/pᵢ) sobre n = ∏ pᵢ^aᵢ (OEIS A003415).
    Para semiprimos n=p·q: n'=p+q — el resultado que Luis ya estableció
    en MOPN. Este motor debe poder re-derivarlo desde cero como test de
    sanidad antes de que se le crea nada más."""
    if n <= 1:
        return 0
    factores = factorizar(n)
    total = Fraction(0)
    for p, a in factores.items():
        total += Fraction(a, p)
    resultado = Fraction(n) * total
    assert resultado.denominator == 1, f"derivada no entera para {n}: {resultado}"
    return int(resultado)


def euler_phi(n: int) -> int:
    factores = factorizar(n)
    resultado = n
    for p in factores:
        resultado = resultado // p * (p - 1)
    return resultado


def suma_divisores(n: int) -> int:
    factores = factorizar(n)
    resultado = 1
    for p, a in factores.items():
        resultado *= (p ** (a + 1) - 1) // (p - 1)
    return resultado


def num_divisores(n: int) -> int:
    factores = factorizar(n)
    resultado = 1
    for a in factores.values():
        resultado *= (a + 1)
    return resultado


FUNCIONES_ARITMETICAS: Dict[str, Callable[[int], int]] = {
    "n": lambda n: n,
    "nprime": derivada_aritmetica,
    "phi": euler_phi,
    "sigma": suma_divisores,
    "tau": num_divisores,
    "uno": lambda n: 1,
}


def primos_hasta(limite: int) -> List[int]:
    return [n for n in range(2, limite + 1) if es_primo(n)]


def generar_semiprimos(n_muestras: int, p_max: int = 300, seed: int = 42,
                        excluir: Optional[set] = None) -> List[int]:
    """n_muestras semiprimos distintos n=p·q, p≠q primos ≤ p_max."""
    rng = random.Random(seed)
    primos = primos_hasta(p_max)
    excluir = excluir or set()
    semiprimos: set = set()
    intentos = 0
    max_intentos = n_muestras * 200 + 2000
    while len(semiprimos) < n_muestras and intentos < max_intentos:
        p, q = rng.sample(primos, 2)
        val = p * q
        if val not in excluir:
            semiprimos.add(val)
        intentos += 1
    return sorted(semiprimos)[:n_muestras]


# ============================================================
# PARTE II — ÁLGEBRA LINEAL EXACTA (Fraction, sin dependencias)
# El núcleo real del motor de minería: encuentra TODAS las relaciones
# lineales que se anulan idénticamente sobre las muestras dadas.
# ============================================================

def _rref(matriz: List[List[Fraction]]) -> Tuple[List[List[Fraction]], List[int]]:
    """RREF por eliminación gaussiana exacta. Devuelve (matriz, columnas_pivote)."""
    M = [row[:] for row in matriz]
    n_filas = len(M)
    n_cols = len(M[0]) if n_filas else 0
    fila = 0
    pivotes: List[int] = []
    for col in range(n_cols):
        piv = None
        for r in range(fila, n_filas):
            if M[r][col] != 0:
                piv = r
                break
        if piv is None:
            continue
        M[fila], M[piv] = M[piv], M[fila]
        pv = M[fila][col]
        M[fila] = [x / pv for x in M[fila]]
        for r in range(n_filas):
            if r != fila and M[r][col] != 0:
                factor = M[r][col]
                M[r] = [M[r][c] - factor * M[fila][c] for c in range(n_cols)]
        pivotes.append(col)
        fila += 1
        if fila == n_filas:
            break
    return M, pivotes


def espacio_nulo(matriz: List[List[Fraction]], n_cols: int) -> List[List[Fraction]]:
    """Base del espacio nulo: cada vector es una relación lineal EXACTA que
    se anula sobre TODAS las filas (muestras) dadas — no una aproximación."""
    M, pivotes = _rref(matriz)
    columnas_pivote = set(pivotes)
    libres = [c for c in range(n_cols) if c not in columnas_pivote]
    base = []
    for lib in libres:
        vec = [Fraction(0)] * n_cols
        vec[lib] = Fraction(1)
        for i, pc in enumerate(pivotes):
            vec[pc] = -M[i][lib]
        base.append(vec)
    return base


def escalar_a_enteros(vec: List[Fraction]) -> List[int]:
    """mcm de denominadores → entero; /mcd → primitivo; signo normalizado."""
    mcm = 1
    for f in vec:
        mcm = mcm * f.denominator // gcd(mcm, f.denominator)
    enteros = [int(f * mcm) for f in vec]
    no_nulos = [abs(x) for x in enteros if x != 0]
    if no_nulos:
        g = reduce(gcd, no_nulos)
        if g > 1:
            enteros = [x // g for x in enteros]
    for x in enteros:
        if x != 0:
            if x < 0:
                enteros = [-x for x in enteros]
            break
    return enteros


def _norma_l1(v: List[int]) -> int:
    return sum(abs(x) for x in v)


def _primitivo(v: List[int]) -> List[int]:
    no_nulos = [abs(x) for x in v if x != 0]
    if not no_nulos:
        return v
    g = reduce(gcd, no_nulos)
    return [x // g for x in v] if g > 1 else v[:]


def reducir_base(base: List[List[int]], iteraciones: int = 15) -> List[List[int]]:
    """Reducción tipo 'poor-man's LLL': el espacio nulo es un subespacio, y
    CUALQUIER combinación entera de sus generadores es una identidad
    igualmente válida — pero no todas las bases son igual de legibles. Esto
    busca, por reducción por pares, representantes de norma L1 mínima, para
    que el motor reporte 'phi+nprime=n+1' en vez de una combinación oscura
    de esa identidad con otras dos. Es cosmético, no epistémico: no cambia
    qué es verdadero, sólo cómo se lee."""
    base = [v[:] for v in base]
    for _ in range(iteraciones):
        mejorado = False
        for i in range(len(base)):
            for j in range(len(base)):
                if i == j:
                    continue
                for signo in (1, -1):
                    cand = _primitivo([a + signo * b for a, b in zip(base[i], base[j])])
                    if any(cand) and _norma_l1(cand) < _norma_l1(base[i]):
                        base[i] = cand
                        mejorado = True
        if not mejorado:
            break
    normalizada = []
    for v in base:
        for x in v:
            if x != 0:
                if x < 0:
                    v = [-y for y in v]
                break
        normalizada.append(v)
    return normalizada


def rango(matriz: List[List[int]]) -> int:
    _, pivotes = _rref([[Fraction(x) for x in fila] for fila in matriz])
    return len(pivotes)


def en_span(base: List[List[int]], objetivo: List[int]) -> bool:
    """¿El vector `objetivo` es combinación lineal de `base`? (la forma
    correcta de comprobar '¿el motor encontró esta identidad?' cuando el
    motor puede devolver una base equivalente pero distinta)."""
    if not base:
        return all(x == 0 for x in objetivo)
    return rango(base) == rango(base + [objetivo])


def verificar_simbolicamente_semiprimo(nombres: List[str], coefs: List[int]) -> Optional[bool]:
    """Verificación simbólica INDEPENDIENTE de la muestra: para n=p·q con p,q
    símbolos (no números) ¿la relación colapsa idénticamente a 0? Esto es
    una prueba algebraica, no una conjetura numérica más. Requiere sympy
    (opcional); si no está, devuelve None (no decidido, nunca 'falso')."""
    try:
        from sympy import symbols, expand, simplify
    except ImportError:
        return None
    p, q = symbols("p q", positive=True)
    valores = {"n": p * q, "nprime": p + q, "phi": (p - 1) * (q - 1),
               "sigma": (1 + p) * (1 + q), "tau": 4, "uno": 1}
    expr = sum(c * valores[nombre] for nombre, c in zip(nombres, coefs))
    return bool(simplify(expand(expr)) == 0)


@dataclass
class RelacionCandidata:
    nombres_funciones: List[str]
    coeficientes: List[int]
    clase_enteros: str
    n_muestras_ajuste: int
    n_muestras_validacion: int
    n_fallos_validacion: int
    formula: str
    prueba_simbolica: Optional[bool] = None


def formatear_relacion(nombres: List[str], coefs: List[int]) -> str:
    etiqueta = {"n": "n", "nprime": "nprime(n)", "phi": "phi(n)",
                "sigma": "sigma(n)", "tau": "tau(n)"}
    terminos = []
    for nombre, c in zip(nombres, coefs):
        if c == 0:
            continue
        if nombre == "uno":
            texto = f"{abs(c)}"
        else:
            lbl = etiqueta.get(nombre, f"{nombre}(n)")
            texto = lbl if abs(c) == 1 else f"{abs(c)}*{lbl}"
        terminos.append((c >= 0, texto))
    if not terminos:
        return "0 = 0"
    partes = [terminos[0][1] if terminos[0][0] else f"-{terminos[0][1]}"]
    for signo, texto in terminos[1:]:
        partes.append(("+ " if signo else "- ") + texto)
    return " ".join(partes) + " = 0"


def minar_relaciones(nombres_funciones: List[str],
                      clase: str = "semiprimos",
                      n_ajuste: int = 12,
                      n_validacion: int = 300,
                      seed: int = 42) -> List[RelacionCandidata]:
    """GENESIS-MATEMÁTICO. Busca relaciones Σ cᵢ·fᵢ(n)=0 exactas sobre una
    clase de enteros. No es regresión: no tolera error en el ajuste, y
    exige CERO fallos sobre una muestra de validación mucho mayor y
    disjunta de la de ajuste antes de considerar la relación viva."""
    if clase != "semiprimos":
        raise ValueError("Sólo la clase 'semiprimos' está implementada en este prototipo.")

    funciones = [FUNCIONES_ARITMETICAS[nom] for nom in nombres_funciones]
    muestras_ajuste = generar_semiprimos(n_ajuste, seed=seed)
    matriz = [[Fraction(f(n)) for f in funciones] for n in muestras_ajuste]
    base_nula = espacio_nulo(matriz, len(nombres_funciones))

    muestras_validacion = generar_semiprimos(n_validacion, seed=seed + 1,
                                              excluir=set(muestras_ajuste))

    base_entera = [escalar_a_enteros(vec) for vec in base_nula]
    base_entera = [v for v in base_entera if any(c != 0 for c in v)]
    base_entera = reducir_base(base_entera)  # generadores más legibles, mismo subespacio

    candidatos = []
    for coefs in base_entera:
        if all(c == 0 for c in coefs):
            continue
        fallos = sum(
            1 for n in muestras_validacion
            if sum(c * f(n) for c, f in zip(coefs, funciones)) != 0
        )
        cand = RelacionCandidata(
            nombres_funciones=nombres_funciones,
            coeficientes=coefs,
            clase_enteros=clase,
            n_muestras_ajuste=n_ajuste,
            n_muestras_validacion=len(muestras_validacion),
            n_fallos_validacion=fallos,
            formula=formatear_relacion(nombres_funciones, coefs),
        )
        cand.prueba_simbolica = verificar_simbolicamente_semiprimo(nombres_funciones, coefs)
        candidatos.append(cand)
    return candidatos


# ============================================================
# PARTE III — PUENTE A DECES: candidato matemático → Claim → auditoría
# ============================================================

def candidato_a_claim(cand: RelacionCandidata) -> Claim:
    nota_prueba = {
        True: "Demostrado simbólicamente (identidad algebraica en p,q arbitrarios; sympy.simplify).",
        False: "La verificación simbólica NO confirma identidad general — riesgo de artefacto de muestra.",
        None: "Verificación simbólica no disponible en este entorno (sympy no instalado).",
    }[cand.prueba_simbolica]

    raw = (f"[GENESIS-MATEMÁTICO] Conjetura sobre {cand.clase_enteros}: {cand.formula}. "
           f"Encontrada por búsqueda de espacio nulo exacto sobre funciones "
           f"aritméticas {cand.nombres_funciones}.")
    premisas = [
        f"Para todo entero de clase '{cand.clase_enteros}' se postula la relación exacta: {cand.formula}.",
        f"Funciones involucradas: {', '.join(cand.nombres_funciones)}.",
        nota_prueba,
    ]
    predicciones = [
        f"Residuo exactamente 0 en {cand.n_muestras_ajuste} muestras de ajuste.",
        f"Validado fuera de muestra en {cand.n_muestras_validacion} casos adicionales, con {cand.n_fallos_validacion} fallos.",
        f"Predicción puntual: cualquier {cand.clase_enteros} nuevo debe dar residuo 0 en {cand.formula}.",
    ]
    return Claim(
        raw_input=raw,
        dominio="matemáticas",
        premisas=premisas,
        predicciones=predicciones,
        supuestos_implicitos=[f"Clase de enteros restringida a {cand.clase_enteros}."],
        marcos_competidores=marcos_por_dominio("matemáticas"),
        ecuaciones=[cand.formula],
        parametros_libres=[],
    )


def audit_claim(claim: Claim, llm_caller: Optional[Callable] = None,
                 modelo: str = "genesis", use_cache: bool = True,
                 similarity_threshold: float = 0.85) -> Veredicto:
    """Idéntico al audit() de deces.py, salvo que arranca de un Claim ya
    construido en vez de texto libre (GENESIS ya tiene la estructura exacta;
    reparsear con regex sería más frágil, no más simple). Memoria, 6 agentes,
    integrador y traza son EXACTAMENTE el código de deces.py — cero líneas
    del núcleo tocadas."""
    conn = get_db()
    if use_cache:
        prev = buscar_claim_exacto(conn, claim)
        if prev:
            v = veredicto_from_dict(prev, claim)
            v.modelo = f"{modelo} (cached)"
            guardar_traza_archivo(v, claim)
            conn.close()
            return v
        if similarity_threshold > 0:
            similares = buscar_claims_similares(conn, claim, threshold=similarity_threshold, limit=1)
            if similares:
                similar_v = cargar_veredicto_db(conn, similares[0]["claim_id"])
                if similar_v:
                    v = veredicto_from_dict(similar_v, claim)
                    v.modelo = f"{modelo} (cached from {similares[0]['claim_id']})"
                    v.similar_to = similares[0]["claim_id"]
                    guardar_claim_db(conn, claim)
                    guardar_veredicto_db(conn, v)
                    guardar_traza_archivo(v, claim)
                    conn.close()
                    return v
    reports = ejecutar_agentes_paralelo(claim, llm_caller=llm_caller)
    veredicto = integrar(reports, claim, modelo=modelo)
    guardar_claim_db(conn, claim)
    guardar_veredicto_db(conn, veredicto)
    guardar_traza_archivo(veredicto, claim)
    conn.close()
    return veredicto


# ============================================================
# PARTE IV — GENESIS-FÍSICO: regresión de leyes de potencia
# ============================================================

@dataclass
class DatoFisico:
    entradas: Dict[str, float]
    salida: float


def generar_datos_sinteticos(n: int = 80, seed: int = 7,
                              ruido: float = 0.01) -> Tuple[List[DatoFisico], Dict[str, float], float]:
    """Datos sintéticos de una ley de potencia OCULTA y=C·x1^a1·x2^a2·x3^a3
    con ruido multiplicativo. Sólo para probar el mecanismo: en uso real,
    `datos` vendría de mediciones (Planck 2018, DESI-BAO DR2, GWOSC, etc.)."""
    rng = random.Random(seed)
    exp_reales = {"x1": 2.0, "x2": -1.0, "x3": 0.5}
    C_real = 3.0
    datos = []
    for _ in range(n):
        x1, x2, x3 = rng.uniform(1.0, 10.0), rng.uniform(1.0, 10.0), rng.uniform(1.0, 10.0)
        y_limpio = C_real * x1 ** exp_reales["x1"] * x2 ** exp_reales["x2"] * x3 ** exp_reales["x3"]
        y = y_limpio * (1.0 + rng.uniform(-ruido, ruido))
        datos.append(DatoFisico(entradas={"x1": x1, "x2": x2, "x3": x3}, salida=y))
    return datos, exp_reales, C_real


@dataclass
class CargaCSV:
    datos: List[DatoFisico]
    n_filas_totales: int
    n_filas_validas: int
    n_descartadas_no_positivas: int
    n_descartadas_faltantes: int


def cargar_datos_csv(ruta: str, variables: List[str], columna_objetivo: str) -> CargaCSV:
    """Puente a datos REALES (Planck 2018, DESI-BAO DR2, GWOSC exportados a
    CSV, o cualquier otro dataset tabular). Misma DatoFisico que produce
    generar_datos_sinteticos() — el resto del pipeline (ajustar_ley_potencia,
    generar_candidato_fisico, candidato_fisico_a_claim) no distingue origen.

    La regresión log-log EXIGE valores positivos (log de negativo o cero no
    está definido). Filas con algún valor ≤0 o faltante se descartan, y se
    cuentan explícitamente — nunca en silencio, en el mismo espíritu que A4
    de deces.py nunca inventa evidencia que no encontró."""
    datos: List[DatoFisico] = []
    n_totales = 0
    n_no_positivas = 0
    n_faltantes = 0
    with open(ruta, "r", encoding="utf-8", newline="") as f:
        lector = csv.DictReader(f)
        columnas_faltantes = [c for c in variables + [columna_objetivo] if c not in (lector.fieldnames or [])]
        if columnas_faltantes:
            raise ValueError(f"Columnas no encontradas en {ruta}: {columnas_faltantes}. "
                              f"Columnas disponibles: {lector.fieldnames}")
        for fila in lector:
            n_totales += 1
            try:
                entradas = {v: float(fila[v]) for v in variables}
                salida = float(fila[columna_objetivo])
            except (ValueError, KeyError):
                n_faltantes += 1
                continue
            if salida <= 0 or any(x <= 0 for x in entradas.values()):
                n_no_positivas += 1
                continue
            datos.append(DatoFisico(entradas=entradas, salida=salida))
    return CargaCSV(
        datos=datos, n_filas_totales=n_totales, n_filas_validas=len(datos),
        n_descartadas_no_positivas=n_no_positivas, n_descartadas_faltantes=n_faltantes,
    )


def _minimos_cuadrados_fallback(X: List[List[float]], y: List[float]) -> List[float]:
    """Ecuaciones normales resueltas por Gauss con pivoteo parcial — usado
    sólo si numpy no está disponible (mismo patrón 'opcional' que Z3/SymPy
    en A1 de deces.py)."""
    k = len(X[0])
    XtX = [[sum(X[i][a] * X[i][b] for i in range(len(X))) for b in range(k)] for a in range(k)]
    Xty = [sum(X[i][a] * y[i] for i in range(len(X))) for a in range(k)]
    A = [row[:] + [Xty[i]] for i, row in enumerate(XtX)]
    for col in range(k):
        piv = max(range(col, k), key=lambda r: abs(A[r][col]))
        A[col], A[piv] = A[piv], A[col]
        pv = A[col][col]
        if abs(pv) < 1e-12:
            continue
        A[col] = [v / pv for v in A[col]]
        for r in range(k):
            if r != col:
                factor = A[r][col]
                A[r] = [A[r][c] - factor * A[col][c] for c in range(k + 1)]
    return [A[i][k] for i in range(k)]


def ajustar_ley_potencia(datos: List[DatoFisico], variables: List[str]) -> Tuple[float, Dict[str, float], float]:
    """log(y) = log(C) + Σ aᵢ·log(xᵢ) — lineal en log-log. Prefiere numpy
    (lstsq); si no está, usa el fallback de ecuaciones normales."""
    X = [[1.0] + [math.log(d.entradas[v]) for v in variables] for d in datos]
    Y = [math.log(d.salida) for d in datos]
    try:
        import numpy as np
        beta = list(np.linalg.lstsq(np.array(X), np.array(Y), rcond=None)[0])
    except ImportError:
        beta = _minimos_cuadrados_fallback(X, Y)

    log_c, exponentes = beta[0], {v: beta[i + 1] for i, v in enumerate(variables)}
    C = math.exp(log_c)
    y_pred = [log_c + sum(exponentes[v] * math.log(d.entradas[v]) for v in variables) for d in datos]
    media = sum(Y) / len(Y)
    ss_tot = sum((yv - media) ** 2 for yv in Y)
    ss_res = sum((yv - yp) ** 2 for yv, yp in zip(Y, y_pred))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 1.0
    return C, exponentes, r2


def redondear_exponentes(exponentes: Dict[str, float], paso: float = 0.5) -> Dict[str, float]:
    """'Navaja de Ockham computacional': redondea a fracciones simples.
    La pérdida de R² por redondear se mide explícitamente, nunca se oculta."""
    return {v: round(e / paso) * paso for v, e in exponentes.items()}


@dataclass
class CandidatoFisico:
    variables: List[str]
    exponentes_libres: Dict[str, float]
    exponentes_redondeados: Dict[str, float]
    C_libre: float
    C_redondeado: float
    r2_libre: float
    r2_redondeado: float
    formula: str


def generar_candidato_fisico(datos: List[DatoFisico], variables: List[str]) -> CandidatoFisico:
    """GENESIS-FÍSICO (prototipo): ajusta libre, redondea exponentes,
    re-ajusta sólo la constante para el modelo redondeado, y reporta AMBOS
    R² para que la pérdida de parsimonia sea visible, no implícita."""
    C_libre, exp_libres, r2_libre = ajustar_ley_potencia(datos, variables)
    exp_redondeados = redondear_exponentes(exp_libres)

    residuales = [math.log(d.salida) - sum(exp_redondeados[v] * math.log(d.entradas[v]) for v in variables)
                  for d in datos]
    log_c_r = sum(residuales) / len(residuales)
    C_redondeado = math.exp(log_c_r)

    Y = [math.log(d.salida) for d in datos]
    y_pred_r = [log_c_r + sum(exp_redondeados[v] * math.log(d.entradas[v]) for v in variables) for d in datos]
    media = sum(Y) / len(Y)
    ss_tot = sum((yv - media) ** 2 for yv in Y)
    ss_res = sum((yv - yp) ** 2 for yv, yp in zip(Y, y_pred_r))
    r2_redondeado = 1 - ss_res / ss_tot if ss_tot > 0 else 1.0

    formula = f"y = {C_redondeado:.4g} * " + " * ".join(f"{v}^{exp_redondeados[v]:g}" for v in variables)
    return CandidatoFisico(variables, exp_libres, exp_redondeados, C_libre, C_redondeado,
                            r2_libre, r2_redondeado, formula)


def candidato_fisico_a_claim(cand: CandidatoFisico, n_datos: int,
                              contexto: str = "dataset sintético (demo — sustituir por datos reales)",
                              nota_calidad_datos: Optional[str] = None) -> Claim:
    raw = (f"[GENESIS-FÍSICO] Ley de potencia candidata sobre {contexto}: {cand.formula}. "
           f"R² libre={cand.r2_libre:.4f}; R² con exponentes redondeados={cand.r2_redondeado:.4f}.")
    premisas = [
        f"Regresión log-log sobre {n_datos} observaciones sugiere: {cand.formula}.",
        f"Exponentes de ajuste libre antes de redondear: {cand.exponentes_libres}.",
        "Exponentes redondeados a múltiplos de 0.5; la pérdida de ajuste por hacerlo se mide explícitamente (no se oculta).",
    ]
    predicciones = [
        f"R² del modelo redondeado = {cand.r2_redondeado:.4f} sobre {n_datos} puntos.",
        f"Predicción cuantitativa: {cand.formula}.",
    ]
    supuestos = [
        "No se impuso consistencia dimensional en este prototipo — siguiente iteración natural: acoplar con el chequeo dimensional que ya existe en A1.",
    ]
    if nota_calidad_datos:
        supuestos.append(nota_calidad_datos)
    else:
        supuestos.append("Datos sintéticos en esta demo; en uso real sustituir generar_datos_sinteticos() por datos medidos (Planck 2018, DESI-BAO DR2, GWOSC).")
    return Claim(
        raw_input=raw, dominio="física", premisas=premisas, predicciones=predicciones,
        supuestos_implicitos=supuestos, marcos_competidores=marcos_por_dominio("física"),
        ecuaciones=[cand.formula], parametros_libres=["C"],
    )


# ============================================================
# PARTE V — AUTO-TEST: ¿el motor redescubre resultados YA CONOCIDOS?
# (mismo principio que test_deces.py, pero valida al GENERADOR, no al juez)
# ============================================================

def test_genesis_matematico() -> Dict[str, Any]:
    print("[TEST GENESIS-MATEMÁTICO] ¿redescubre phi(n)+nprime(n)=n+1 y "
          "sigma(n)=n+nprime(n)+1 para semiprimos, sin que se le digan?", file=sys.stderr)
    candidatos = minar_relaciones(
        nombres_funciones=["n", "nprime", "phi", "sigma", "tau", "uno"],
        clase="semiprimos", n_ajuste=12, n_validacion=300, seed=42)

    nombres = ["n", "nprime", "phi", "sigma", "tau", "uno"]
    objetivo_phi = [-1, 1, 1, 0, 0, -1]      # phi(n) + nprime(n) - n - 1 = 0
    objetivo_sigma = [-1, -1, 0, 1, 0, -1]   # sigma(n) - nprime(n) - n - 1 = 0

    # Nota metodológica: el espacio nulo es un SUBESPACIO — la base que RREF
    # devuelve depende del orden de pivoteo y puede no ser, coeficiente a
    # coeficiente, la que un humano habría escrito a mano (aunque
    # reducir_base() ya intenta acercarla). Lo que hay que comprobar no es
    # "¿aparece exactamente este vector?" sino "¿esta identidad es
    # consecuencia lineal de lo que el motor encontró?" — es decir,
    # pertenencia al span, que es la propiedad matemáticamente relevante.
    base_encontrada = [c.coeficientes for c in candidatos]
    encontro_phi = en_span(base_encontrada, objetivo_phi)
    encontro_sigma = en_span(base_encontrada, objetivo_sigma)
    todas_validadas = all(c.n_fallos_validacion == 0 for c in candidatos) if candidatos else False

    print(f"  Relaciones encontradas: {len(candidatos)}", file=sys.stderr)
    for c in candidatos:
        print(f"    {c.formula}   [fallos_validación={c.n_fallos_validacion}/{c.n_muestras_validacion}, "
              f"prueba_simbólica={c.prueba_simbolica}]", file=sys.stderr)

    passed = encontro_phi and encontro_sigma and todas_validadas
    return {"pass": passed, "n_candidatos": len(candidatos), "encontro_phi": encontro_phi,
            "encontro_sigma": encontro_sigma, "todas_validadas": todas_validadas,
            "candidatos": candidatos}


def test_genesis_fisico() -> Dict[str, Any]:
    print("[TEST GENESIS-FÍSICO] ¿redescubre y=3*x1^2*x2^-1*x3^0.5 desde datos sintéticos con ruido?",
          file=sys.stderr)
    datos, exp_reales, c_real = generar_datos_sinteticos(n=80, seed=7, ruido=0.01)
    cand = generar_candidato_fisico(datos, ["x1", "x2", "x3"])
    print(f"  Exponentes reales:       {exp_reales}  (C={c_real})", file=sys.stderr)
    print(f"  Recuperados (libre):     {{{', '.join(f'{k}: {v:.4f}' for k, v in cand.exponentes_libres.items())}}}  (C={cand.C_libre:.4f})", file=sys.stderr)
    print(f"  Recuperados (redondeado): {cand.exponentes_redondeados}  (C={cand.C_redondeado:.4f})", file=sys.stderr)
    print(f"  R² libre={cand.r2_libre:.6f}   R² redondeado={cand.r2_redondeado:.6f}", file=sys.stderr)
    exponentes_ok = all(abs(cand.exponentes_redondeados[v] - exp_reales[v]) < 1e-9 for v in exp_reales)
    passed = exponentes_ok and cand.r2_redondeado > 0.99
    return {"pass": passed, "candidato": cand, "exp_reales": exp_reales, "c_real": c_real}


# ============================================================
# CLI
# ============================================================

def cmd_test(args):
    r1 = test_genesis_matematico()
    r2 = test_genesis_fisico()
    print()
    print("=" * 70)
    print(f"GENESIS-MATEMÁTICO : {'PASS' if r1['pass'] else 'FAIL'}  "
          f"({r1['n_candidatos']} relaciones, todas validadas fuera de muestra={r1['todas_validadas']})")
    print(f"GENESIS-FÍSICO      : {'PASS' if r2['pass'] else 'FAIL'}  "
          f"(R² redondeado={r2['candidato'].r2_redondeado:.5f})")
    if not (r1["pass"] and r2["pass"]):
        sys.exit(1)


def cmd_minar(args):
    candidatos = minar_relaciones(
        nombres_funciones=args.funciones.split(","), clase=args.clase,
        n_ajuste=args.n_ajuste, n_validacion=args.n_validacion, seed=args.seed)
    print(f"\n{len(candidatos)} relación(es) encontradas para clase='{args.clase}' "
          f"sobre funciones {args.funciones}:\n")
    for c in candidatos:
        print(f"  {c.formula}")
        print(f"    validación fuera de muestra: {c.n_fallos_validacion}/{c.n_muestras_validacion} fallos"
              f" · prueba simbólica: {c.prueba_simbolica}")
    if args.auditar:
        for c in candidatos:
            claim = candidato_a_claim(c)
            v = audit_claim(claim, modelo="genesis-cli", use_cache=not args.no_cache)
            print("\n" + render_veredicto_texto(v))
            print(f"  [GENESIS] prueba_simbólica_independiente = {c.prueba_simbolica}")


def cmd_fisico_demo(args):
    r = test_genesis_fisico()
    cand = r["candidato"]
    print(f"\nFórmula candidata: {cand.formula}")
    if args.auditar:
        claim = candidato_fisico_a_claim(cand, n_datos=80)
        v = audit_claim(claim, modelo="genesis-fisico-cli", use_cache=not args.no_cache)
        print("\n" + render_veredicto_texto(v))


def cmd_fisico_csv(args):
    """GENESIS-FÍSICO sobre datos REALES (CSV) — la contraparte no-sintética
    de fisico-demo. Todo lo demás del pipeline es idéntico: log-log,
    redondeo Ockham, R² explícito, Claim, auditoría DECES completa."""
    variables = args.variables.split(",")
    carga = cargar_datos_csv(args.csv, variables, args.objetivo)

    print(f"Filas leídas       : {carga.n_filas_totales}")
    print(f"Filas válidas      : {carga.n_filas_validas}")
    print(f"Descartadas (≤0)   : {carga.n_descartadas_no_positivas}  (log-log exige valores positivos)")
    print(f"Descartadas (falt.): {carga.n_descartadas_faltantes}")

    if carga.n_filas_validas < len(variables) + 2:
        print(f"\nError: sólo {carga.n_filas_validas} filas válidas para {len(variables)} variables — "
              f"insuficiente para un ajuste con sentido (mínimo recomendado: {len(variables) + 5}).",
              file=sys.stderr)
        sys.exit(1)

    cand = generar_candidato_fisico(carga.datos, variables)
    print(f"\nFórmula candidata: {cand.formula}")
    print(f"R² libre={cand.r2_libre:.6f}   R² redondeado={cand.r2_redondeado:.6f}")

    if args.auditar:
        pct_descartado = 100 * (1 - carga.n_filas_validas / carga.n_filas_totales) if carga.n_filas_totales else 0
        nota = (f"Datos de {args.csv} ({args.contexto}): {carga.n_filas_validas}/{carga.n_filas_totales} filas "
                f"válidas usadas ({pct_descartado:.1f}% descartado por valores ≤0 o faltantes).")
        claim = candidato_fisico_a_claim(cand, n_datos=carga.n_filas_validas,
                                          contexto=args.contexto, nota_calidad_datos=nota)
        v = audit_claim(claim, modelo="genesis-fisico-csv", use_cache=not args.no_cache)
        print("\n" + render_veredicto_texto(v))


def main():
    p = argparse.ArgumentParser(prog="genesis", description="GENESIS — Capa -1 de descubrimiento para DECES.")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_test = sub.add_parser("test", help="Auto-test: ¿el motor redescubre identidades ya conocidas?")
    p_test.set_defaults(func=cmd_test)

    p_minar = sub.add_parser("minar", help="Buscar relaciones aritméticas exactas (GENESIS-MATEMÁTICO)")
    p_minar.add_argument("--clase", default="semiprimos")
    p_minar.add_argument("--funciones", default="n,nprime,phi,sigma,tau,uno")
    p_minar.add_argument("--n-ajuste", type=int, default=12)
    p_minar.add_argument("--n-validacion", type=int, default=300)
    p_minar.add_argument("--seed", type=int, default=42)
    p_minar.add_argument("--auditar", action="store_true", help="Pasar cada candidato por el panel DECES completo (A1-A6)")
    p_minar.add_argument("--no-cache", action="store_true")
    p_minar.set_defaults(func=cmd_minar)

    p_fis = sub.add_parser("fisico-demo", help="Demo de regresión de ley de potencia (GENESIS-FÍSICO, datos sintéticos)")
    p_fis.add_argument("--auditar", action="store_true")
    p_fis.add_argument("--no-cache", action="store_true")
    p_fis.set_defaults(func=cmd_fisico_demo)

    p_fis_csv = sub.add_parser("fisico", help="Regresión de ley de potencia sobre datos REALES (GENESIS-FÍSICO, CSV)")
    p_fis_csv.add_argument("--csv", required=True, help="Ruta al archivo CSV con los datos")
    p_fis_csv.add_argument("--variables", required=True, help="Columnas de entrada, separadas por coma (ej: masa,radio)")
    p_fis_csv.add_argument("--objetivo", required=True, help="Columna de salida a explicar")
    p_fis_csv.add_argument("--contexto", default="dataset provisto por el usuario",
                            help="Descripción breve del dataset (ej: 'Planck 2018 TT+lowE')")
    p_fis_csv.add_argument("--auditar", action="store_true")
    p_fis_csv.add_argument("--no-cache", action="store_true")
    p_fis_csv.set_defaults(func=cmd_fisico_csv)

    args = p.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
