@echo off
REM ============================================================
REM  DECES v3.2 - instalador para Windows (sin conocimientos previos)
REM  Requisito unico: Python 3.10 o mas nuevo (python.org)
REM ============================================================
echo.
echo [DECES] Verificando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no esta instalado o no esta en PATH.
    echo         Descargalo de https://www.python.org/downloads/
    echo         y marca la casilla "Add python.exe to PATH".
    pause
    exit /b 1
)
python --version

echo.
echo [DECES] Instalando dependencias (sympy, z3-solver)...
python -m pip install --upgrade pip >nul
python -m pip install sympy z3-solver
if errorlevel 1 (
    echo [ERROR] No se pudieron instalar las dependencias. Revisa tu internet.
    pause
    exit /b 1
)

echo.
echo [DECES] Corriendo la suite de verificacion (7 casos historicos)...
python "%~dp0deces.py" test --no-llm
echo.
echo ============================================================
echo  LISTO. Para auditar un claim:
echo    python "%~dp0deces.py" audit "tu afirmacion cientifica" --claro
echo  Para auditar un archivo:
echo    python "%~dp0deces.py" audit --input mi_paper.txt --claro
echo  Manual en lenguaje simple: MANUAL_HUMANO.md
echo ============================================================
pause
