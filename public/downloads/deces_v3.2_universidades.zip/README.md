# DECES v3.2 — packages/deces (runtime canónico)

**Tribunal epistémico adversarial self-hosted.** No descubre: JUZGA. Un claim científico
entra; 8 agentes heterogéneos lo atacan en paralelo; sale un veredicto nivel 0–5 con
score R, objeciones priorizadas, experimento discriminante y **sello SHA256 + traza
reproducible**. Para universidades y para cualquier persona (ver `MANUAL_HUMANO.md` —
lenguaje simple, `--claro`).

**Origen:** deces.py de Tyr (bóveda, iteración 2026-07-10 03:04) → v3.1 (REGISTRO_REFUTADOS,
sello) → **v3.2 (2026-07-10): implementa la spec `DECES_Herramienta_v7.pdf`** (en
`02_MAESTROS_BRAIN_OS/03_MOI_DECES/`).

## Qué hay de nuevo en v3.2
1. **A1+ análisis dimensional** (sympy): homogeneidad real de unidades con tabla +
   heurística de prefijos documentada. Caza verificado: `τ_S = 1/(α·c·Ṅe)` → [T]≠[T²/L]
   (el bug real de TCR Der. III).
2. **A7 consistencia numérica interna**: recomputa ratios del propio texto. Caza
   verificado: "1.08× la cota"=0.108 invertido, "1.000000 universal", conteos enteros <1.
3. **`is_fatal`**: refutación concluyente (p. ej. REGISTRO_REFUTADOS) colapsa a nivel 0
   por vía formal en AMBOS integradores.
4. **Dos integradores** (`--integrador geometrico|ponderado`, env `DECES_INTEGRADOR`):
   geométrico sigue siendo DEFAULT. Evidencia medida 2026-07-10: bajo `ponderado` un
   claim SIN predicciones falsables puntúa nivel 4 (R≈0.68) — inaceptable para la
   filosofía del tribunal; queda como opt-in de la spec v7 con esta advertencia.
5. **Abstención** (hallazgo propio): un agente sin nada verificable que decir NO
   participa y los pesos se renormalizan. Sin esto, los agentes nuevos con score 1.0
   diluían los exponentes e inflaban R 0.5701→0.7235 en el caso TCR. El tribunal se
   auditó a sí mismo.
6. **A4 con consulta dirigida de contradicción** ("<término> refuted OR superseded").
7. **`--claro`**: explicación del veredicto en lenguaje llano es-MX (accesibilidad).
8. **Empaquetado**: `pyproject.toml` (comando `deces`), `INSTALAR_WINDOWS.bat`,
   `instalar_mac.sh`, `MANUAL_HUMANO.md`, `MANUAL_UNIVERSIDADES.md`.

## Evidencia fechada (2026-07-10)
- Suite histórica: **7/7** con los 8 agentes (OPERA, éter, B–H, Vulcano, fusión fría,
  RG, Mochizuki). pytest: **6/6**. Memoria: speedup 220× en re-auditoría.
- Re-auditoría TCR v3.2 (geométrico + LLM local, mismas condiciones del sello vigente):
  **Nivel 3, R=0.5676, sello `4ff540938df6b631`** — estable con el 3/0.5701 de v3.1
  (deriva 0.0025 = renormalización + variación LLM). El nivel honesto de TCR sigue 3.

## Uso
```
# instalar (una vez): doble clic INSTALAR_WINDOWS.bat  |  sh instalar_mac.sh
python deces.py audit "claim" --claro          # veredicto + lenguaje simple
python deces.py audit --input paper.txt        # documento completo
python deces.py audit --arxiv 1109.4897        # abstract de arXiv
python deces.py audit ... --integrador ponderado   # spec v7 §5 (ver advertencia)
python deces.py test                           # suite histórica 7 casos
set DECES_HOME=<dir>                           # default ~/.deces
```
Sin internet: A4 avisa y se degrada honesto. Sin GPU / 4 GB RAM: funciona completo
(el LLM local por Ollama es opcional, mejora A3/A6).

## Deuda conocida (siguiente iteración)
- Ingest traga la autodescripción del claim ("0 parámetros libres") sin verificarla.
- A1: traducción SMT completa a Z3 (hoy: sintáctico + fallback regex, documentado).
- A1+: tabla de símbolos ampliable; ecuaciones opacas → abstención (no penaliza fuerte).
- Integración MOI→DECES v0 por subprocess: spec en `03_MOI_DECES/SPEC_INTEGRACION_MOI_DECES_v0.md`.

## Regla del sello
Ningún documento porta «DECES · Nivel X» sin sello + traza JSON adjunta del MISMO
documento. Sello de una versión anterior = veredicto NO vigente.
