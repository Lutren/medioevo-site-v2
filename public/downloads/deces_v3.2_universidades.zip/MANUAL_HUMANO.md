# DECES — Manual en lenguaje simple
*Para cualquier persona. No necesitas saber programar ni haber ido a la universidad.*

## Qué es DECES
Es un programa que **pone a prueba afirmaciones científicas**. Tú le das una afirmación
("los neutrinos viajan más rápido que la luz", "mi teoría predice X") y ocho "jueces"
automáticos la atacan desde ángulos distintos: ¿se contradice a sí misma?, ¿sus unidades
físicas cuadran?, ¿se puede poner a prueba?, ¿qué dice la literatura científica real?,
¿usa palabras infladas?, ¿ya existe algo más simple que explica lo mismo?, ¿sus números
internos cuadran?

DECES **no dice qué es verdad**. Dice qué tan bien sobrevive tu afirmación a un ataque
honesto — con un número (R, de 0 a 1) y un nivel (0 a 5).

## Instalar (una sola vez)
- **Windows:** doble clic en `INSTALAR_WINDOWS.bat`. Si pide Python, instálalo de
  python.org marcando "Add python.exe to PATH", y vuelve a dar doble clic.
- **Mac/Linux:** abre Terminal en esta carpeta y escribe `sh instalar_mac.sh`.
- Funciona en computadoras modestas (4 GB de RAM, sin tarjeta de video). No necesita
  cuentas ni llaves de nada.

## Usar
Abre una terminal en esta carpeta y escribe:
```
python deces.py audit "tu afirmación aquí" --claro
```
El `--claro` añade al final una explicación en palabras simples: qué significa el nivel,
cuál es el problema más serio encontrado, y qué hacer con el resultado.

También puedes auditar un documento entero:
```
python deces.py audit --input mi_documento.txt --claro
```

## Cómo leer el resultado
| Nivel | Significa | Qué hacer |
|---|---|---|
| 0 | Contradicha | No la uses. Revisa la objeción principal. |
| 1 | Muy improbable | Casi todo apunta en contra. |
| 2 | Especulativa | Idea coherente SIN evidencia. Preséntala como especulación. |
| 3 | Compatible | Hipótesis seria con forma de probarse. NO demostrada. |
| 4 | Prometedora | Varias líneas de evidencia. Sigue siendo provisional. |
| 5 | Fuertemente respaldada | Sobrevivió muchos intentos de refutación. |

## El sello (importante)
Cada veredicto termina con una línea `SELLO DECES: nivel=X R=Y claim=0x... hash=...`.
Ese sello es la huella digital del veredicto: si alguien te dice "esto pasó DECES con
nivel 4", pídele el sello Y la traza (el archivo .json que se guarda en la carpeta
`traces`). **Sin sello y traza, la frase "pasó DECES" no vale nada** — así evitamos que
la herramienta se use para inflar afirmaciones.

## Honestidad sobre los límites
- Sin internet, el juez de evidencia (A4) avisa que no pudo buscar literatura y el
  veredicto se apoya en los demás jueces.
- DECES es un filtro de calidad reproducible, **no un experto humano** ni la verdad final.
- El modo con IA local (Ollama) es opcional y mejora dos jueces; sin él, todo funciona
  con reglas deterministas.

*Creado por Luis René González López (Tyr), México. Licencia MIT: úsalo, cópialo,
mejóralo. "El primer principio es no engañarte a ti mismo." — Feynman*
