# DECES v3.2 — Manual para universidades y grupos de investigación
*(English summary at the end)*

## Propósito
DECES es un tribunal epistémico adversarial reproducible: recibe un claim científico y
produce un veredicto **auditable y re-ejecutable** (nivel 0–5, score R, objeciones
priorizadas, experimento discriminante, traza JSON con sello SHA256). Su caso de uso
académico: pre-filtro de calidad para manuscritos propios, material didáctico de
falsabilidad, y auditoría sistemática de afirmaciones (p. ej., en revisiones).

## Arquitectura (4 capas, 8 agentes)
1. **Ingest** — texto libre → Claim estructurado (premisas, predicciones, ecuaciones,
   parámetros libres, marcos competidores).
2. **Panel adversarial (paralelo)** —
   A1 lógica (Z3/SymPy) · A1+ análisis dimensional (sympy, tabla+heurística de prefijos
   documentada) · A2 parsimonia (MDL/compresión) · A3 falsabilidad (plantilla o LLM
   local) · A4 evidencia real (arXiv+OpenAlex con caché, REGISTRO de refutaciones
   históricas → `is_fatal`, y consulta dirigida de contradicción "<término> refuted OR
   superseded") · A5 hipóstasis · A6 marco competidor · A7 consistencia numérica interna
   (recomputa ratios del propio texto).
3. **Integrador** — dos métodos seleccionables:
   - `geometrico` (default): producto ponderado; agresivo a propósito (un score 0 no
     fatal colapsa). Los agentes **abstenidos** (nada verificable que decir) NO
     participan y los pesos se renormalizan — sin esto, agentes silenciosos inflan R
     (medido: 0.5701→0.7235 en el caso TCR, 2026-07-10).
   - `ponderado` (spec v7 §5): media ponderada + penalización por varianza + flag fatal.
     ADVERTENCIA medida: un claim sin predicciones falsables puntúa nivel 4 (R≈0.68)
     bajo este método; por eso NO es el default.
   - Refutación concluyente (`is_fatal`) colapsa a nivel 0 en ambos métodos.
4. **Traza** — JSON+TXT+SQLite; **sello** = SHA256(traza)[:16].

## Reproducibilidad y cita de veredictos
- Un veredicto se cita ÚNICAMENTE con su sello completo:
  `nivel=X R=Y claim=0x… hash=…` + la traza JSON adjunta.
- Re-auditar: `deces audit --input claim.txt --no-cache` (fuerza re-ejecución).
  Con las mismas entradas y sin LLM, el pipeline es determinista módulo el estado de las
  APIs externas (la caché de 7 días estabiliza ventanas de reproducción).
- El modo LLM (Ollama local) mejora A3/A6 pero introduce variación; para publicación
  reporte ambos: con y sin LLM.

## Evidencia de validación (fechada 2026-07-10)
- Suite histórica 7/7: OPERA, éter, Bekenstein–Hawking, Vulcano, fusión fría, RG,
  Mochizuki ABC.
- Sanity de agentes nuevos contra bugs reales: A1+ detecta `τ_S = 1/(α·c·Ṅe)` como
  [T]≠[T²/L]; A7 detecta ratio invertido "1.08×"=0.108, "1.000000 universal" y conteos
  enteros <1.
- Caso de estudio completo (teoría TCR, 8 documentos, 3 auditorías): nivel honesto 3,
  R≈0.57 estable entre v3.1 y v3.2.

## Límites declarados
- A1 usa Z3 en modo sintáctico (traducción SMT completa = roadmap).
- A1+ requiere símbolos resolubles (tabla/heurística); ecuaciones opacas → abstención.
- Ingest acepta la autodescripción del claim (p. ej. "0 parámetros libres") sin
  verificarla — deuda documentada.
- Los "teoremas" de completeness/soundness del paper acompañante MIP-het son
  aspiracionales, no demostraciones (pipeline determinista).

## English summary
DECES is a self-hosted adversarial epistemic tribunal: 8 heterogeneous agents attack a
scientific claim (logic/Z3, dimensional analysis, MDL parsimony, falsifiability, real
literature via arXiv/OpenAlex + a registry of conclusively refuted theories with fatal
flag, hypostasis, competing frameworks, internal numeric consistency). Verdicts are
reproducible (JSON trace + SHA256 seal); two aggregators (geometric default; weighted
mean per spec v7 — measured to inflate unfalsifiable claims, hence not default).
MIT license. Python ≥3.10, runs on 4 GB RAM without GPU; LLM (local Ollama) optional.
